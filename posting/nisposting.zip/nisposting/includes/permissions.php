<?php
// Function to check if user has a specific permission
function hasPermission($permission_name) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    // Get user's role from the session
    $role_id = $_SESSION['role_id'] ?? null;
    
    if (!$role_id) {
        return false;
    }
    
    global $pdo;
    
    try {
        // Check if the user's role has this permission
        $stmt = $pdo->prepare("
            SELECT 1 
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role_id = ? AND p.name = ?
        ");
        $stmt->execute([$role_id, $permission_name]);
        
        return $stmt->fetch() !== false;
    } catch (PDOException $e) {
        // Log error if needed
        return false;
    }
}
?>
