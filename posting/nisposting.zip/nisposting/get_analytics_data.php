<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

try {
    // Enable error reporting for development
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
    
    // Verify database connection
    if (!$pdo) {
        throw new Exception('Database connection not established');
    }

    // Get total personnel with active postings
    $totalPersonnel = $pdo->query("
        SELECT COUNT(DISTINCT p.id) 
        FROM personnel p 
        JOIN postings po ON p.id = po.personnel_id 
        WHERE po.posting_status = 'Active'"
    )->fetchColumn();

    // Get total active users
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

    // Get formation distribution with active postings
    $formations = $pdo->query("
        SELECT f.location_type as formation_type, COUNT(DISTINCT p.id) as count 
        FROM formations f
        LEFT JOIN postings po ON f.id = po.formation_id
        LEFT JOIN personnel p ON po.personnel_id = p.id
        WHERE po.posting_status = 'Active'
        GROUP BY f.location_type
        ORDER BY count DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Get rank distribution for active postings
    $ranks = $pdo->query("
        SELECT p.rank, COUNT(DISTINCT p.id) as count 
        FROM personnel p
        JOIN postings po ON p.id = po.personnel_id
        WHERE po.posting_status = 'Active'
        GROUP BY p.rank
        ORDER BY count DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Get gender distribution for active postings
    $gender = $pdo->query("
        SELECT p.gender, COUNT(DISTINCT p.id) as count 
        FROM personnel p
        JOIN postings po ON p.id = po.personnel_id
        WHERE po.posting_status = 'Active'
        GROUP BY p.gender
        ORDER BY count DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Enhanced age distribution query with better grouping
    $age = $pdo->query("
        SELECT 
            age_group,
            COUNT(DISTINCT id) as count
        FROM (
            SELECT 
                p.id,
                CASE 
                    WHEN TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) < 25 THEN '18-24'
                    WHEN TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) BETWEEN 25 AND 34 THEN '25-34'
                    WHEN TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) BETWEEN 35 AND 44 THEN '35-44'
                    WHEN TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) BETWEEN 45 AND 54 THEN '45-54'
                    ELSE '55+'
                END as age_group
            FROM personnel p
            JOIN postings po ON p.id = po.personnel_id
            WHERE po.posting_status = 'Active'
        ) age_calc
        GROUP BY age_group
        ORDER BY 
            CASE age_group
                WHEN '18-24' THEN 1
                WHEN '25-34' THEN 2
                WHEN '35-44' THEN 3
                WHEN '45-54' THEN 4
                WHEN '55+' THEN 5
            END
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Get recent activities with username
    $recentActivities = $pdo->query("
        SELECT 
            al.id,
            al.action,
            al.created_at,
            COALESCE(u.username, 'System') as username
        FROM activity_logs al
        LEFT JOIN users u ON al.user_id = u.id
        ORDER BY al.created_at DESC
        LIMIT 5
    ")->fetchAll(PDO::FETCH_ASSOC);

    $response = [
        'success' => true,
        'data' => [
            'summary' => [
                'total_personnel' => (int)$totalPersonnel,
                'total_users' => (int)$totalUsers,
                'active_postings' => (int)$totalPersonnel
            ],
            'formations' => $formations ?: [],
            'ranks' => $ranks ?: [],
            'gender' => $gender ?: [],
            'age' => $age ?: [],
            'recent_activities' => $recentActivities ?: []
        ]
    ];

    echo json_encode($response);

} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error occurred',
        'debug' => [
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]
    ]);
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
