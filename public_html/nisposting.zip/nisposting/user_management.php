<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
session_start();

// Include required files
try {
    require_once 'includes/config.php';
    require_once 'includes/auth.php';
    require_once 'includes/permissions.php';
} catch (Exception $e) {
    die("Error loading required files: " . $e->getMessage());
}

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get current user info for sidebar - RENAMED FROM $current_user TO $user
try {
    $stmt = $pdo->prepare("
        SELECT u.*, r.name as role_name
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        $user = [
            'username' => $_SESSION['username'] ?? 'User',
            'full_name' => $_SESSION['username'] ?? 'User',
            'role_name' => 'User'
        ];
    }
} catch (Exception $e) {
    $user = [
        'username' => $_SESSION['username'] ?? 'User',
        'full_name' => $_SESSION['username'] ?? 'User',
        'role_name' => 'User'
    ];
}

// Initialize variables
$error = '';
$success = '';
$users = [];
$roles = [];
$zones = [];
$user_zones = [];

try {
    // Get all users with their roles
    $query = "
        SELECT 
            u.id, u.username, u.full_name, u.email, 
            u.status, u.created_at, u.last_login,
            r.name as role_name, r.id as role_id
        FROM users u
        JOIN roles r ON u.role_id = r.id
        ORDER BY u.created_at DESC
    ";
    
    // If user is Zone Admin, only show users from their zone
    if (isZoneAdmin() && !isSuperAdmin() && !isServiceHQ()) {
        $currentUserZones = getUserZones($_SESSION['user_id']);
        if (!empty($currentUserZones)) {
            $zoneIds = implode(',', array_column($currentUserZones, 'id'));
            $query = "
                SELECT 
                    u.id, u.username, u.full_name, u.email, 
                    u.status, u.created_at, u.last_login,
                    r.name as role_name, r.id as role_id
                FROM users u
                JOIN roles r ON u.role_id = r.id
                JOIN user_zones uz ON u.id = uz.user_id
                WHERE uz.zone_id IN ($zoneIds)
                GROUP BY u.id
                ORDER BY u.created_at DESC
            ";
        }
    }
    
    $users = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all roles
    $roles = $pdo->query("SELECT id, name, description FROM roles ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all zones
    $zones = $pdo->query("SELECT id, zone_name, zone_code FROM zones ORDER BY zone_name")->fetchAll(PDO::FETCH_ASSOC);
    
    // Get zones the current user can manage
    if (isSuperAdmin() || isServiceHQ()) {
        $user_zones = $zones; // Can manage all zones
    } else {
        $user_zones = getUserZones($_SESSION['user_id']);
    }
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Create new user
        if (isset($_POST['create_user'])) {
            $username = trim($_POST['username']);
            $full_name = trim($_POST['full_name']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            $role_id = $_POST['role_id'];
            $assigned_zones = isset($_POST['zones']) ? $_POST['zones'] : [];
            
            // Validation
            if (empty($username) || empty($full_name) || empty($email) || empty($password)) {
                $error = "All fields are required.";
            } elseif ($password !== $confirm_password) {
                $error = "Passwords do not match.";
            } elseif (strlen($password) < 8) {
                $error = "Password must be at least 8 characters long.";
            } else {
                // Check if username exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $email]);
                if ($stmt->rowCount() > 0) {
                    $error = "Username or email already exists.";
                } else {
                    // Get role information
                    $stmt = $pdo->prepare("SELECT name FROM roles WHERE id = ?");
                    $stmt->execute([$role_id]);
                    $role = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Check permissions for role assignment
                    if (isZoneAdmin() && !isSuperAdmin() && !isServiceHQ()) {
                        // Zone Admins can only create Zone-level roles
                        if ($role['name'] === 'Super Admin' || $role['name'] === 'Service HQ') {
                            $error = "You don't have permission to assign this role.";
                        }
                    }
                    
                    if (isServiceHQ() && !isSuperAdmin()) {
                        // Service HQ can't create Super Admins
                        if ($role['name'] === 'Super Admin') {
                            $error = "You don't have permission to assign this role.";
                        }
                    }
                    
                    if (empty($error)) {
                        // Hash password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        
                        // Start transaction
                        $pdo->beginTransaction();
                        
                        try {
                            // Create user
                            $stmt = $pdo->prepare("
                                INSERT INTO users (username, full_name, email, password, role_id, status, created_by)
                                VALUES (?, ?, ?, ?, ?, 'active', ?)
                            ");
                            $stmt->execute([$username, $full_name, $email, $hashed_password, $role_id, $_SESSION['user_id']]);
                            $user_id = $pdo->lastInsertId();
                            
                            // Assign zones if applicable
                            if (!empty($assigned_zones)) {
                                // Check if user can assign these zones
                                $allowedZoneIds = array_column($user_zones, 'id');
                                foreach ($assigned_zones as $zone_id) {
                                    if (in_array($zone_id, $allowedZoneIds)) {
                                        $stmt = $pdo->prepare("INSERT INTO user_zones (user_id, zone_id) VALUES (?, ?)");
                                        $stmt->execute([$user_id, $zone_id]);
                                    }
                                }
                            }
                            
                            // Log activity
                            logActivity("Created user: $username with role: " . $role['name']);
                            
                            $pdo->commit();
                            $success = "User created successfully.";
                            
                        } catch (Exception $e) {
                            $pdo->rollBack();
                            $error = "Failed to create user: " . $e->getMessage();
                        }
                    }
                }
            }
        }
        
        // Update user status
        if (isset($_POST['update_status'])) {
            $user_id = $_POST['user_id'];
            $status = $_POST['status'];
            
            // Check permission to modify this user
            if (canModifyUser($_SESSION['user_id'], $user_id)) {
                $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
                $stmt->execute([$status, $user_id]);
                
                // Get username for logging
                $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
                
                logActivity("Updated user status: {$user_info['username']} to $status");
                $success = "User status updated successfully.";
            } else {
                $error = "You don't have permission to modify this user.";
            }
        }
        
        // Update user role
        if (isset($_POST['update_role'])) {
            $user_id = $_POST['user_id'];
            $role_id = $_POST['role_id'];
            
            // Check permission to modify this user
            if (canModifyUser($_SESSION['user_id'], $user_id)) {
                // Get new role information
                $stmt = $pdo->prepare("SELECT name FROM roles WHERE id = ?");
                $stmt->execute([$role_id]);
                $new_role = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Check permissions for role assignment
                if (isZoneAdmin() && !isSuperAdmin() && !isServiceHQ()) {
                    if ($new_role['name'] === 'Super Admin' || $new_role['name'] === 'Service HQ') {
                        $error = "You don't have permission to assign this role.";
                    }
                }
                
                if (isServiceHQ() && !isSuperAdmin()) {
                    if ($new_role['name'] === 'Super Admin') {
                        $error = "You don't have permission to assign this role.";
                    }
                }
                
                if (empty($error)) {
                    $stmt = $pdo->prepare("UPDATE users SET role_id = ? WHERE id = ?");
                    $stmt->execute([$role_id, $user_id]);
                    
                    // Get username for logging
                    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    logActivity("Updated user role: {$user_info['username']} to " . $new_role['name']);
                    $success = "User role updated successfully.";
                }
            } else {
                $error = "You don't have permission to modify this user.";
            }
        }
        
        // Update user zones
        if (isset($_POST['update_zones'])) {
            $user_id = $_POST['user_id'];
            $assigned_zones = isset($_POST['zones']) ? $_POST['zones'] : [];
            
            // Check permission to modify this user
            if (canModifyUser($_SESSION['user_id'], $user_id)) {
                // Start transaction
                $pdo->beginTransaction();
                
                try {
                    // Remove existing zones
                    $stmt = $pdo->prepare("DELETE FROM user_zones WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                    
                    // Add new zones
                    $allowedZoneIds = array_column($user_zones, 'id');
                    foreach ($assigned_zones as $zone_id) {
                        if (in_array($zone_id, $allowedZoneIds)) {
                            $stmt = $pdo->prepare("INSERT INTO user_zones (user_id, zone_id) VALUES (?, ?)");
                            $stmt->execute([$user_id, $zone_id]);
                        }
                    }
                    
                    // Get username for logging
                    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    logActivity("Updated zones for user: {$user_info['username']}");
                    $pdo->commit();
                    $success = "User zones updated successfully.";
                    
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = "Failed to update user zones: " . $e->getMessage();
                }
            } else {
                $error = "You don't have permission to modify this user.";
            }
        }
        
        // Reset user password
        if (isset($_POST['reset_password'])) {
            $user_id = $_POST['user_id'];
            $new_password = bin2hex(random_bytes(8)); // Generate random password
            
            // Check permission to modify this user
            if (canModifyUser($_SESSION['user_id'], $user_id)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $user_id]);
                
                // Get user info for notification
                $stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user_info = $stmt->fetch(PDO::FETCH_ASSOC);
                
                logActivity("Reset password for user: {$user_info['username']}");
                $success = "Password reset successfully. New password: <strong>$new_password</strong>";
            } else {
                $error = "You don't have permission to modify this user.";
            }
        }
        
    } catch (Exception $e) {
        $error = "Operation failed: " . $e->getMessage();
    }
    
    // Refresh page to show changes
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <title>NIS-PPMS - User Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* CSS Reset */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        /* Body styling */
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: 
                linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(39, 174, 96, 0.9) 100%),
                url('assets/images/tech_building.jpg') center/cover no-repeat fixed;
            min-height: 100vh;
            color: #333;
        }
        
        /* Header styling */
        .header-container {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 0.8rem 2rem;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(5px);
            border-bottom: 2px solid #27ae60;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo-title-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .header-logo {
            height: 50px;
            width: auto;
            object-fit: contain;
        }
        
        .system-title {
            color: #2c3e50;
            font-size: 1.4rem;
            font-weight: 800;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-profile {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        /* Dashboard layout */
        .dashboard-container {
            padding: 2rem;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .content-wrapper {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }
        
        /* Main content */
        .main-content {
            flex: 1;
            min-width: 300px;
            background: rgba(255, 255, 255, 0.98);
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
            overflow: hidden;
            border: 1px solid rgba(39, 174, 96, 0.1);
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .card-header {
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            color: white;
            padding: 1rem 1.5rem;
            font-weight: 600;
            font-size: 1.1rem;
            border: none;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* Stats cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(39, 174, 96, 0.9) 100%);
            color: white;
            border-radius: 12px;
            padding: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .stat-card.primary {
            background: linear-gradient(135deg, #2c3e50 0%, #4a90e2 100%);
        }
        
        .stat-card.info {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
        }
        
        .stat-content h3 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.3rem;
        }
        
        .stat-content p {
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .stat-icon {
            background: rgba(255, 255, 255, 0.2);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        /* Form styling */
        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 15px;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            color: var(--secondary-color);
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-group label i {
            margin-right: 6px;
            color: var(--primary-color);
            width: 16px;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s;
            background-color: white;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        
        .form-control::placeholder {
            color: #999;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #2c3e50 0%, #4a90e2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(52, 152, 219, 0.25);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
        }
        
        .btn-success:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(39, 174, 96, 0.25);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
        }
        
        .btn-danger:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(231, 76, 60, 0.25);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
        }
        
        .btn-warning:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(243, 156, 18, 0.25);
        }
        
        .btn-block {
            width: 100%;
        }
        
        .btn-sm {
            padding: 5px 12px;
            font-size: 12px;
        }
        
        /* Users List Card */
        .users-list-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-top: 4px solid #4a90e2;
        }
        
        /* Table styling */
        .table-responsive {
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            overflow: hidden;
        }
        
        .users-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .users-table thead {
            background-color: #f8fafc;
        }
        
        .users-table th {
            padding: 14px 16px;
            text-align: left;
            color: #2c3e50;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e0e0e0;
        }
        
        .users-table td {
            padding: 16px;
            border-bottom: 1px solid #e0e0e0;
            vertical-align: middle;
        }
        
        .users-table tbody tr {
            transition: background-color 0.2s;
        }
        
        .users-table tbody tr:hover {
            background-color: #f9f9f9;
        }
        
        /* User info in table */
        .user-cell {
            display: flex;
            flex-direction: column;
        }
        
        .user-name {
            font-weight: 500;
            color: #2c3e50;
        }
        
        .user-email {
            font-size: 12px;
            color: #666;
            margin-top: 2px;
        }
        
        /* Status badges */
        .status-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .status-active {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .status-suspended {
            background-color: #fff3cd;
            color: #856404;
        }
        
        /* Role badges */
        .role-badge {
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .role-admin {
            background-color: #e3f2fd;
            color: #1565c0;
        }
        
        .role-user {
            background-color: #f3e5f5;
            color: #7b1fa2;
        }
        
        /* Action buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn-icon {
            width: 32px;
            height: 32px;
            padding: 0;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #ddd;
            background: white;
            color: #666;
            transition: all 0.3s;
        }
        
        .btn-icon:hover {
            background-color: #f8f9fa;
            transform: translateY(-1px);
        }
        
        .btn-edit {
            color: #4a90e2;
        }
        
        .btn-delete {
            color: #e74c3c;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #999;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #e0e0e0;
        }
        
        .empty-state h4 {
            color: #666;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .empty-state p {
            font-size: 14px;
        }
        
        /* Alerts */
        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
            font-size: 14px;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #27ae60;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #e74c3c;
        }
        
        .alert i {
            font-size: 18px;
        }
        
        /* Zone checkboxes */
        .zone-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 10px;
            margin-top: 10px;
        }
        
        .zone-checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .zone-checkbox:hover {
            background-color: #f8f9fa;
            border-color: #4a90e2;
        }
        
        .zone-checkbox input[type="checkbox"] {
            margin: 0;
            width: auto;
        }
        
        /* Zone tags */
        .zone-tag {
            background: #e8f5e9;
            color: #27ae60;
            padding: 4px 8px;
            border-radius: 15px;
            font-size: 12px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin: 2px;
        }
        
        /* Permission info */
        .permission-info {
            background: #e3f2fd;
            padding: 12px 16px;
            border-radius: 6px;
            margin: 15px 0;
            font-size: 14px;
            border-left: 4px solid #4a90e2;
        }
        
        /* User count badge */
        .user-count {
            background: #e3f2fd;
            color: #1565c0;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
        }
        
        /* Modal styling */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(135deg, #2c3e50 0%, #4a90e2 100%);
            color: white;
            border-radius: 12px 12px 0 0;
        }
        
        .modal-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: white;
            opacity: 0.8;
            transition: opacity 0.3s;
        }
        
        .close-modal:hover {
            opacity: 1;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1rem;
            }
            
            .content-wrapper {
                flex-direction: column;
                gap: 1rem;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .header-container {
                padding: 0.8rem 1rem;
            }
            
            .header-logo {
                height: 40px;
            }
            
            .system-title {
                font-size: 1.1rem;
            }
            
            .card-body {
                padding: 1rem;
            }
            
            .users-table {
                font-size: 13px;
            }
            
            .users-table th,
            .users-table td {
                padding: 10px;
            }
            
            .action-buttons {
                flex-direction: column;
                width: 100%;
            }
            
            .action-buttons .btn-icon {
                width: 100%;
                margin-bottom: 5px;
            }
        }
        
        @media (max-width: 576px) {
            .header-content {
                flex-direction: column;
                gap: 0.8rem;
                align-items: flex-start;
            }
            
            .logo-title-container {
                width: 100%;
                justify-content: space-between;
            }
            
            .user-info {
                width: 100%;
                justify-content: flex-end;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .zone-grid {
                grid-template-columns: 1fr;
            }
        }
        
        /* Page Title */
        .page-title {
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            color: white;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-radius: 12px;
        }
        
        .page-title h1 {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.8rem;
            margin: 0;
        }
        
        /* Content grid */
        .content-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 2rem;
        }
        
        @media (max-width: 1024px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header-container">
        <div class="header-content">
            <div class="logo-title-container">
                <img src="assets/images/logo.png" alt="NIS Logo" class="header-logo">
                <h1 class="system-title">NIS Personnel Posting Management System</h1>
            </div>
            <div class="user-info">
                <div class="user-profile">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></strong><br>
                    <small><?php echo htmlspecialchars($user['role_name']); ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <!-- Alerts -->
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> 
                <div><?php echo $success; ?></div>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> 
                <div><?php echo $error; ?></div>
            </div>
        <?php endif; ?>

        <div class="content-wrapper">
            <!-- Include Sidebar -->
            <?php include 'includes/sidebar.php'; ?>

            <!-- Main Content -->
            <div class="main-content">
                <!-- Page Title -->
                <div class="page-title">
                    <h1>
                        <i class="fas fa-users-cog"></i>
                        User Management
                    </h1>
                </div>

                <div class="content-grid">
                    <!-- Create User Card -->
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3> Create New User</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="">
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label><i class="fas fa-user"></i> Username *</label>
                                            <input type="text" name="username" class="form-control" required 
                                                   placeholder="Enter username">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label><i class="fas fa-id-card"></i> Full Name *</label>
                                            <input type="text" name="full_name" class="form-control" required 
                                                   placeholder="Enter full name">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Email *</label>
                                        <input type="email" name="email" class="form-control" required 
                                               placeholder="Enter email address">
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label> Password *</label>
                                            <input type="password" name="password" class="form-control" required 
                                                   placeholder="Minimum 8 characters" minlength="8">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Confirm Password *</label>
                                            <input type="password" name="confirm_password" class="form-control" required 
                                                   placeholder="Confirm password" minlength="8">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Role *</label>
                                        <select name="role_id" class="form-control" required>
                                            <option value="">Select Role</option>
                                            <?php foreach ($roles as $role): 
                                                // Filter roles based on user permissions
                                                if (isZoneAdmin() && !isSuperAdmin() && !isServiceHQ()) {
                                                    if ($role['name'] === 'Super Admin' || $role['name'] === 'Service HQ') {
                                                        continue;
                                                    }
                                                }
                                                
                                                if (isServiceHQ() && !isSuperAdmin()) {
                                                    if ($role['name'] === 'Super Admin') {
                                                        continue;
                                                    }
                                                }
                                            ?>
                                                <option value="<?php echo $role['id']; ?>">
                                                    <?php echo htmlspecialchars($role['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <?php if (!empty($user_zones)): ?>
                                    <div class="form-group">
                                        <label><i class="fas fa-map-marker-alt"></i> Assign Zones</label>
                                        <div class="zone-grid">
                                            <?php foreach ($user_zones as $zone): ?>
                                            <label class="zone-checkbox">
                                                <input type="checkbox" name="zones[]" value="<?php echo $zone['id']; ?>">
                                                <span><?php echo htmlspecialchars($zone['zone_name'] ?? $zone['zone_code']); ?></span>
                                            </label>
                                            <?php endforeach; ?>
                                        </div>
                                        <small style="color: #666; font-size: 12px;">Select zones this user can manage</small>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <button type="submit" name="create_user" class="btn btn-success btn-block">
                                        <i class="fas fa-user-plus"></i> Create User
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <?php if (!empty($user_zones)): ?>
                        <div class="permission-info">
                            <i class="fas fa-info-circle"></i>
                            <div>
                                <strong>Your Zone Permissions:</strong> You can manage users in 
                                <?php 
                                    $zone_names = array_column($user_zones, 'zone_name');
                                    echo implode(', ', $zone_names);
                                ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Users List Card -->
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <h3>System Users</h3>
                                    <div class="user-count">Total: <?php echo count($users); ?></div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <?php if (empty($users)): ?>
                                        <div class="empty-state">
                                            <i class="fas fa-users-slash"></i>
                                            <h4>No Users Found</h4>
                                            <p>Start by creating your first user using the form on the left.</p>
                                        </div>
                                    <?php else: ?>
                                        <table class="users-table">
                                            <thead>
                                                <tr>
                                                    <th>User</th>
                                                    <th>Role</th>
                                                    <th>Status</th>
                                                    <th>Last Login</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($users as $user_record): 
                                                    // Get user's assigned zones
                                                    $stmt = $pdo->prepare("
                                                        SELECT z.zone_name, z.zone_code 
                                                        FROM user_zones uz 
                                                        JOIN zones z ON uz.zone_id = z.id 
                                                        WHERE uz.user_id = ?
                                                    ");
                                                    $stmt->execute([$user_record['id']]);
                                                    $user_assigned_zones = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                                    
                                                    // Check if current user can modify this user
                                                    $can_modify = canModifyUser($_SESSION['user_id'], $user_record['id']);
                                                ?>
                                                <tr>
                                                    <td>
                                                        <div class="user-cell">
                                                            <span class="user-name"><?php echo htmlspecialchars($user_record['full_name']); ?></span>
                                                            <span class="user-email"><?php echo htmlspecialchars($user_record['email']); ?></span>
                                                            <small style="color: #999; font-size: 11px;">@<?php echo htmlspecialchars($user_record['username']); ?></small>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="role-badge role-admin">
                                                            <?php echo htmlspecialchars($user_record['role_name']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="status-badge status-<?php echo $user_record['status']; ?>">
                                                            <i class="fas fa-circle" style="font-size: 8px;"></i>
                                                            <?php echo ucfirst($user_record['status']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if ($user_record['last_login']): ?>
                                                            <?php echo date('M j, Y', strtotime($user_record['last_login'])); ?><br>
                                                            <small style="color: #999;"><?php echo date('g:i A', strtotime($user_record['last_login'])); ?></small>
                                                        <?php else: ?>
                                                            <span style="color: #999; font-size: 12px;">Never</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($can_modify): ?>
                                                        <div class="action-buttons">
                                                            <button type="button" class="btn-icon btn-warning" 
                                                                    onclick="openStatusModal(<?php echo $user_record['id']; ?>, '<?php echo htmlspecialchars($user_record['username'], ENT_QUOTES); ?>', '<?php echo $user_record['status']; ?>')"
                                                                    title="Change Status">
                                                                <i class="fas fa-exchange-alt"></i>
                                                            </button>
                                                            
                                                            <button type="button" class="btn-icon btn-primary" 
                                                                    onclick="openRoleModal(<?php echo $user_record['id']; ?>, '<?php echo htmlspecialchars($user_record['username'], ENT_QUOTES); ?>', <?php echo $user_record['role_id']; ?>)"
                                                                    title="Change Role">
                                                                <i class="fas fa-user-tag"></i>
                                                            </button>
                                                            
                                                            <?php if (!empty($user_zones)): ?>
                                                            <button type="button" class="btn-icon btn-success" 
                                                                    onclick="openZonesModal(<?php echo $user_record['id']; ?>, '<?php echo htmlspecialchars($user_record['username'], ENT_QUOTES); ?>')"
                                                                    title="Manage Zones">
                                                                <i class="fas fa-map-marker-alt"></i>
                                                            </button>
                                                            <?php endif; ?>
                                                            
                                                            <button type="button" class="btn-icon btn-danger" 
                                                                    onclick="openPasswordModal(<?php echo $user_record['id']; ?>, '<?php echo htmlspecialchars($user_record['username'], ENT_QUOTES); ?>')"
                                                                    title="Reset Password">
                                                                <i class="fas fa-key"></i>
                                                            </button>
                                                        </div>
                                                        <?php else: ?>
                                                        <span style="color: #999; font-size: 12px;">Access</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exchange-alt"></i> Update User Status</h3>
                <button class="close-modal" onclick="closeModal('statusModal')">&times;</button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <p>Update status for user: <strong id="statusUsername"></strong></p>
                    <input type="hidden" name="user_id" id="statusUserId">
                    <div class="form-group">
                        <label for="status">Select Status</label>
                        <select id="status" name="status" class="form-control" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('statusModal')">Cancel</button>
                    <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                </div>
            </form>
        </div>
    </div>
    
    <div id="roleModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-tag"></i> Update User Role</h3>
                <button class="close-modal" onclick="closeModal('roleModal')">&times;</button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <p>Update role for user: <strong id="roleUsername"></strong></p>
                    <input type="hidden" name="user_id" id="roleUserId">
                    <div class="form-group">
                        <label for="role_id">Select Role</label>
                        <select id="modal_role_id" name="role_id" class="form-control" required>
                            <option value="">Select Role</option>
                            <?php foreach ($roles as $role): 
                                // Filter roles based on user permissions
                                if (isZoneAdmin() && !isSuperAdmin() && !isServiceHQ()) {
                                    if ($role['name'] === 'Super Admin' || $role['name'] === 'Service HQ') {
                                        continue;
                                    }
                                }
                                
                                if (isServiceHQ() && !isSuperAdmin()) {
                                    if ($role['name'] === 'Super Admin') {
                                        continue;
                                    }
                                }
                            ?>
                                <option value="<?php echo $role['id']; ?>">
                                    <?php echo htmlspecialchars($role['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('roleModal')">Cancel</button>
                    <button type="submit" name="update_role" class="btn btn-primary">Update Role</button>
                </div>
            </form>
        </div>
    </div>
    
    <div id="zonesModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-map-marker-alt"></i> Update User Zones</h3>
                <button class="close-modal" onclick="closeModal('zonesModal')">&times;</button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <p>Update zones for user: <strong id="zonesUsername"></strong></p>
                    <input type="hidden" name="user_id" id="zonesUserId">
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Assign Zones</label>
                        <div class="zone-grid">
                            <?php foreach ($user_zones as $zone): ?>
                            <label class="zone-checkbox">
                                <input type="checkbox" name="zones[]" value="<?php echo $zone['id']; ?>"
                                       class="zone-checkbox-input">
                                <span><?php echo htmlspecialchars($zone['zone_name'] ?? $zone['zone_code']); ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('zonesModal')">Cancel</button>
                    <button type="submit" name="update_zones" class="btn btn-primary">Update Zones</button>
                </div>
            </form>
        </div>
    </div>
    
    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-key"></i> Reset User Password</h3>
                <button class="close-modal" onclick="closeModal('passwordModal')">&times;</button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <p>Reset password for user: <strong id="passwordUsername"></strong></p>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <div>This will generate a new random password for the user.</div>
                    </div>
                    <input type="hidden" name="user_id" id="passwordUserId">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('passwordModal')">Cancel</button>
                    <button type="submit" name="reset_password" class="btn btn-danger">Reset Password</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // Modal functions
    function openStatusModal(userId, username, currentStatus) {
        document.getElementById('statusUserId').value = userId;
        document.getElementById('statusUsername').textContent = username;
        document.getElementById('status').value = currentStatus;
        document.getElementById('statusModal').style.display = 'flex';
    }
    
    function openRoleModal(userId, username, currentRoleId) {
        document.getElementById('roleUserId').value = userId;
        document.getElementById('roleUsername').textContent = username;
        document.getElementById('modal_role_id').value = currentRoleId;
        document.getElementById('roleModal').style.display = 'flex';
    }
    
    function openZonesModal(userId, username) {
        document.getElementById('zonesUserId').value = userId;
        document.getElementById('zonesUsername').textContent = username;
        
        // Clear all checkboxes first
        document.querySelectorAll('.zone-checkbox-input').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // Fetch user's current zones and check them
        fetch(`get_user_zones.php?user_id=${userId}`)
            .then(response => response.json())
            .then(zones => {
                zones.forEach(zone => {
                    const checkbox = document.querySelector(`.zone-checkbox-input[value="${zone.id}"]`);
                    if (checkbox) {
                        checkbox.checked = true;
                    }
                });
            })
            .catch(error => console.error('Error loading zones:', error));
        
        document.getElementById('zonesModal').style.display = 'flex';
    }
    
    function openPasswordModal(userId, username) {
        document.getElementById('passwordUserId').value = userId;
        document.getElementById('passwordUsername').textContent = username;
        document.getElementById('passwordModal').style.display = 'flex';
    }
    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    }
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        }
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    
    // Form validation
    document.addEventListener('DOMContentLoaded', function() {
        const password = document.querySelector('input[name="password"]');
        const confirmPassword = document.querySelector('input[name="confirm_password"]');
        
        if (password && confirmPassword) {
            function validatePasswords() {
                if (password.value !== confirmPassword.value) {
                    confirmPassword.setCustomValidity('Passwords do not match');
                } else {
                    confirmPassword.setCustomValidity('');
                }
            }
            
            password.addEventListener('change', validatePasswords);
            confirmPassword.addEventListener('keyup', validatePasswords);
        }
    });
    </script>
</body>
</html>