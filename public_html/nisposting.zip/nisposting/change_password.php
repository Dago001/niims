<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $user_id = $_SESSION['user_id'];

    // Verify current password
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (password_verify($current_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 8) {
                // Hash the new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                // Update the password
                $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                
                if ($update_stmt->execute([$hashed_password, $user_id])) {
                    $success = "Password successfully updated!";
                } else {
                    $error = "Error updating password. Please try again.";
                }
            } else {
                $error = "New password must be at least 8 characters long.";
            }
        } else {
            $error = "New passwords do not match.";
        }
    } else {
        $error = "Current password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - NIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-green: #2E7D32;
            --secondary-green: #43A047;
            --light-green: #81C784;
        }
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: linear-gradient(rgba(46, 125, 50, 0.85), rgba(67, 160, 71, 0.9)), url('assets/images/tech_building.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 400px;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 2rem;
        }
        .logo-container img {
            max-width: 150px;
            height: auto;
            margin-bottom: 1rem;
        }
        .form-control {
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 1rem;
        }
        .btn-login {
            background-color: var(--primary-green);
            border: none;
            padding: 12px;
            font-weight: bold;
            width: 100%;
            margin-top: 1rem;
            transition: background-color 0.3s ease;
        }
        .btn-login:hover {
            background-color: var(--secondary-green);
        }
        .error-message {
            background-color: rgba(220, 53, 69, 0.9);
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 1rem;
            text-align: center;
        }
        .success-message {
            background-color: rgba(40, 167, 69, 0.9);
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 1rem;
            text-align: center;
        }
        .password-container {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
            transition: color 0.3s ease;
        }
        .password-toggle:hover {
            color: var(--primary-green);
        }
        .password-requirements {
            font-size: 0.8rem;
            color: #666;
            margin-top: -0.5rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <img src="assets/images/logo.png" alt="NIS Logo">
            <h4>Change Password</h4>
        </div>
        
        <?php if ($error): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3 password-container">
                <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Current Password" required>
                <i class="bi bi-eye-slash password-toggle" id="toggleCurrentPassword"></i>
            </div>

            <div class="mb-3 password-container">
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password" required>
                <i class="bi bi-eye-slash password-toggle" id="toggleNewPassword"></i>
                <div class="password-requirements">Password must be at least 8 characters long</div>
            </div>

            <div class="mb-3 password-container">
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm New Password" required>
                <i class="bi bi-eye-slash password-toggle" id="toggleConfirmPassword"></i>
            </div>

            <button type="submit" class="btn btn-primary btn-login">Update Password</button>
            <a href="dashboard.php" class="btn btn-secondary btn-login mt-2">Back to Dashboard</a>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function setupPasswordToggle(toggleId, inputId) {
            document.getElementById(toggleId).addEventListener('click', function() {
                const passwordInput = document.getElementById(inputId);
                const icon = this;
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                } else {
                    passwordInput.type = 'password';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                }
            });
        }

        // Setup password toggles for all password fields
        setupPasswordToggle('toggleCurrentPassword', 'current_password');
        setupPasswordToggle('toggleNewPassword', 'new_password');
        setupPasswordToggle('toggleConfirmPassword', 'confirm_password');
    </script>
</body>
</html>
</body>
</html>
