<?php
session_start();
require_once 'includes/config.php';

if (!isset($_GET['user_id'])) {
    echo json_encode([]);
    exit();
}

$user_id = $_GET['user_id'];

$stmt = $pdo->prepare("
    SELECT z.id, z.zone_name, z.zone_code 
    FROM user_zones uz 
    JOIN zones z ON uz.zone_id = z.id 
    WHERE uz.user_id = ?
");
$stmt->execute([$user_id]);
$zones = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($zones);
?>