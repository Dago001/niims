<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: personnel.php');
    exit();
}

$id = $_GET['id'];
$record = null;

try {
    $stmt = $pdo->prepare("SELECT * FROM tbl_emppersonal WHERE id = ?");
    $stmt->execute([$id]);
    $record = $stmt->fetch();
    
    if (!$record) {
        die("Record not found.");
    }
} catch (PDOException $e) {
    die("Error fetching record: " . $e->getMessage());
}
?>

<?php include 'includes/header.php'; ?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php include 'includes/sidebar.php'; ?>
        </div>
        
        <div class="col-md-9">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Personnel Details</h5>
                        <a href="personnel.php" class="btn btn-light btn-sm">
                            <i class="fas fa-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">Service Number:</th>
                                    <td><?php echo htmlspecialchars($record['service_number']); ?></td>
                                </tr>
                                <tr>
                                    <th>Rank:</th>
                                    <td><?php echo htmlspecialchars($record['rank']); ?></td>
                                </tr>
                                <tr>
                                    <th>Full Name:</th>
                                    <td><?php echo htmlspecialchars($record['first_name'] . ' ' . $record['last_name']); ?></td>
                                </tr>
                                <tr>
                                    <th>Gender:</th>
                                    <td><?php echo htmlspecialchars($record['gender']); ?></td>
                                </tr>
                                <tr>
                                    <th>Date of Birth:</th>
                                    <td><?php echo htmlspecialchars($record['date_of_birth']); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">State of Origin:</th>
                                    <td><?php echo htmlspecialchars($record['state_of_origin']); ?></td>
                                </tr>
                                <tr>
                                    <th>LGA:</th>
                                    <td><?php echo htmlspecialchars($record['lga']); ?></td>
                                </tr>
                                <tr>
                                    <th>Phone Number:</th>
                                    <td><?php echo htmlspecialchars($record['phone_number']); ?></td>
                                </tr>
                                <tr>
                                    <th>Email:</th>
                                    <td><?php echo htmlspecialchars($record['email']); ?></td>
                                </tr>
                                <tr>
                                    <th>Date Created:</th>
                                    <td><?php echo htmlspecialchars($record['created_at']); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <a href="personnel.php?edit_id=<?php echo $record['id']; ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Edit Record
                        </a>
                        <a href="personnel.php" class="btn btn-secondary">Back to List</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>