
<!-- Sidebar -->
<aside class="sidebar">
    <!-- User Profile Section -->
    <div class="sidebar-profile">
        <div class="profile-avatar">
            <div class="avatar-circle">
                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
            </div>
            <div class="profile-info">
                <h4 class="profile-name"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h4>
                <span class="profile-role"><?php echo htmlspecialchars($user['role_name']); ?></span>
            </div>
            <div class="profile-status">
                <span class="status-indicator online" title="Online"></span>
            </div>
        </div>
        
        <div class="last-login">
            <i class="fas fa-clock"></i>
            <span>Last login: <?php echo date('M j, Y g:i A'); ?></span>
        </div>
    </div>

    <!-- Navigation Menu -->
    <nav class="sidebar-nav">
        <!-- Dashboard -->
        <div class="nav-section">
            <h5 class="nav-section-title">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </h5>
            <ul class="nav-menu">
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-home"></i>
                        <span>Overview</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Personnel Management -->
        <div class="nav-section">
            <h5 class="nav-section-title">
                <i class="fas fa-user-tie"></i>
                <span>Personnel Management</span>
            </h5>
            <ul class="nav-menu">
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'search.php' ? 'active' : ''; ?>">
                    <a href="search.php" class="nav-link">
                        <i class="fas fa-search"></i>
                        <span>Search Records</span>
                    </a>
                </li>
                <!--<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'add_personnel.php' ? 'active' : ''; ?>">-->
                <!--    <a href="add_personnel.php" class="nav-link">-->
                <!--        <i class="fas fa-user-plus"></i>-->
                <!--        <span>Add Personnel</span>-->
                <!--    </a>-->
                <!--</li>-->
                <!--<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'includes/comingsoon.php' ? 'active' : ''; ?>">-->
                <!--    <a href="includes/comingsoon.php" class="nav-link">-->
                <!--        <i class="fas fa-list"></i>-->
                <!--        <span>Personnel List</span>-->
                <!--    </a>-->
                <!--</li>-->
            </ul>
        </div>

        <!-- Reports & Analytics -->
        <div class="nav-section">
            <h5 class="nav-section-title">
                <i class="fas fa-chart-bar"></i>
                <span>Reports & Analytics</span>
            </h5>
            <ul class="nav-menu">
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'includes/comingsoon.php' ? 'active' : ''; ?>">
                    <a href="includes/comingsoon.php" class="nav-link">
                        <i class="fas fa-chart-line"></i>
                        <span>Analytics Dashboard</span>
                    </a>
                </li>
                <li class="nav-item <?php echo strpos($_SERVER['PHP_SELF'], 'reports/') !== false ? 'active' : ''; ?>">
                    <a href="#" class="nav-link has-submenu">
                        <i class="fas fa-file-alt"></i>
                        <span>Reports</span>
                        <i class="fas fa-chevron-down"></i>
                    </a>
                    <ul class="submenu">
                        <!--<li><a href="reports/gender_distribution.php"><i class="fas fa-venus-mars"></i> Gender Report</a></li>-->
                        <!--<li><a href="reports/gender_distribution.php"><i class="fas fa-venus-mars"></i> Gender Report</a></li>-->
                        <!--<li><a href="reports/rank_distribution.php"><i class="fas fa-star"></i> Rank Report</a></li>-->
                        <!--<li><a href="reports/command_distribution.php"><i class="fas fa-building"></i> Command Report</a></li>-->
                        <!--<li><a href="reports/zone_distribution.php"><i class="fas fa-map-marker-alt"></i> Zone Report</a></li>-->
                        <!--<li><a href="reports/activity_logs.php"><i class="fas fa-history"></i> Activity Logs</a></li>-->
                        
                        <li><a href="includes/comingsoon.php"><i class="fas fa-venus-mars"></i> Gender Report</a></li>
                        <li><a href="includes/comingsoon.php"><i class="fas fa-venus-mars"></i> Gender Report</a></li>
                        <li><a href="includes/comingsoon.php"><i class="fas fa-star"></i> Rank Report</a></li>
                        <li><a href="includes/comingsoon.php"><i class="fas fa-building"></i> Command Report</a></li>
                        <li><a href="includes/comingsoon.php"><i class="fas fa-map-marker-alt"></i> Zone Report</a></li>
                        <li><a href="includes/comingsoon.php"><i class="fas fa-history"></i> Activity Logs</a></li>
                    </ul>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'includes/comingsoon.php' ? 'active' : ''; ?>">
                    <a href="includes/comingsoon.php" class="nav-link">
                        <i class="fas fa-file-export"></i>
                        <span>Export Data</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- System Administration -->
        <?php if (function_exists('isSuperAdmin') && isSuperAdmin()): ?>
        <div class="nav-section">
            <h5 class="nav-section-title">
                <i class="fas fa-cogs"></i>
                <span>Administration</span>
            </h5>
            <ul class="nav-menu">
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                    <a href="admin/users.php" class="nav-link">
                        <i class="fas fa-users-cog"></i>
                        <span>User Management</span>
                    </a>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'roles.php' ? 'active' : ''; ?>">
                    <a href="admin/roles.php" class="nav-link">
                        <i class="fas fa-user-tag"></i>
                        <span>Role Management</span>
                    </a>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <a href="admin/settings.php" class="nav-link">
                        <i class="fas fa-sliders-h"></i>
                        <span>System Settings</span>
                    </a>
                </li>
            </ul>
        </div>
        <?php endif; ?>

        <!-- User Account -->
        <div class="nav-section">
            <h5 class="nav-section-title">
                <i class="fas fa-user-circle"></i>
                <span>Administration</span>
            </h5>
            <ul class="nav-menu">
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'user_management.php' ? 'active' : ''; ?>">
                    <a href="user_management.php" class="nav-link">
                        <i class="fas fa-user-edit"></i>
                        <span>User Management</span>
                    </a>
                </li>
                <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'includes/comingsoon.php' ? 'active' : ''; ?>">
                    <a href="includes/comingsoon.php" class="nav-link">
                        <i class="fas fa-key"></i>
                        <span>Change Password</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link logout-link">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- System Status Footer -->
    <div class="sidebar-footer">
        <div class="system-status">
            <div class="status-item">
                <span class="status-label">System Status</span>
                <span class="status-badge success">Online</span>
            </div>
            <div class="status-item">
                <span class="status-label">Last Backup</span>
                <span class="status-text"><?php echo date('M d, Y'); ?></span>
            </div>
        </div>
        <div class="copyright">
            <small>&copy; <?php echo date('Y'); ?> NIS-PPMS v1.0 (Designed and Developed by the NIS Web Team)</small>
        </div>
    </div>
</aside>

<style>
/* Sidebar Styles */
.sidebar {
    width: 280px;
    background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
    color: #ecf0f1;
    display: flex;
    flex-direction: column;
    height: 100%;
    position: relative;
    box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
    z-index: 100;
}

/* Profile Section */
.sidebar-profile {
    padding: 25px 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.2);
}

.profile-avatar {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
    position: relative;
}

.avatar-circle {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: bold;
    margin-right: 15px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.profile-info {
    flex: 1;
}

.profile-name {
    font-size: 16px;
    font-weight: 600;
    margin: 0 0 4px 0;
    color: white;
}

.profile-role {
    font-size: 12px;
    color: #95a5a6;
    background: rgba(255, 255, 255, 0.1);
    padding: 3px 8px;
    border-radius: 12px;
    display: inline-block;
}

.profile-status {
    position: absolute;
    right: 0;
    top: 0;
}

.status-indicator {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: block;
}

.status-indicator.online {
    background: #2ecc71;
    box-shadow: 0 0 0 3px rgba(46, 204, 113, 0.2);
}

/* Profile Stats */
.profile-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 20px;
}

.stat-item {
    display: flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.05);
    padding: 10px;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.stat-item:hover {
    background: rgba(255, 255, 255, 0.1);
    transform: translateY(-2px);
}

.stat-item i {
    font-size: 20px;
    color: #27ae60;
    margin-right: 10px;
}

.stat-value {
    display: block;
    font-size: 18px;
    font-weight: 700;
    color: white;
    line-height: 1.2;
}

.stat-label {
    display: block;
    font-size: 11px;
    color: #95a5a6;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.last-login {
    display: flex;
    align-items: center;
    font-size: 12px;
    color: #bdc3c7;
    padding-top: 10px;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.last-login i {
    margin-right: 8px;
    color: #27ae60;
}

/* Navigation */
.sidebar-nav {
    flex: 1;
    overflow-y: auto;
    padding: 20px 0;
}

.nav-section {
    margin-bottom: 25px;
}

.nav-section-title {
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #7f8c8d;
    padding: 0 20px 10px 20px;
    margin: 0;
    display: flex;
    align-items: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.nav-section-title i {
    margin-right: 10px;
    font-size: 14px;
}

.nav-menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.nav-item {
    position: relative;
}

.nav-link {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    color: #bdc3c7;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.nav-link:hover {
    background: rgba(255, 255, 255, 0.05);
    color: white;
    border-left-color: #27ae60;
}

.nav-link.active {
    background: rgba(39, 174, 96, 0.15);
    color: white;
    border-left-color: #27ae60;
}

.nav-link i {
    width: 20px;
    margin-right: 12px;
    font-size: 16px;
    text-align: center;
}

.nav-link span {
    flex: 1;
    font-size: 14px;
}

.nav-link.has-submenu i.fa-chevron-down {
    font-size: 12px;
    margin-left: auto;
    margin-right: 0;
    transition: transform 0.3s ease;
}

.nav-link.has-submenu.active i.fa-chevron-down {
    transform: rotate(180deg);
}

/* Submenu */
.submenu {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
    background: rgba(0, 0, 0, 0.2);
}

.nav-item.active .submenu {
    max-height: 300px;
}

.submenu li {
    list-style: none;
}

.submenu a {
    display: flex;
    align-items: center;
    padding: 10px 20px 10px 50px;
    color: #95a5a6;
    text-decoration: none;
    font-size: 13px;
    transition: all 0.3s ease;
}

.submenu a:hover {
    background: rgba(255, 255, 255, 0.05);
    color: white;
    padding-left: 55px;
}

.submenu a i {
    font-size: 12px;
    margin-right: 10px;
    width: 15px;
}

/* Logout Link */
.logout-link {
    color: #e74c3c !important;
}

.logout-link:hover {
    background: rgba(231, 76, 60, 0.1) !important;
    border-left-color: #e74c3c !important;
}

/* Footer */
.sidebar-footer {
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    padding: 15px 20px;
    background: rgba(0, 0, 0, 0.2);
}

.system-status {
    margin-bottom: 15px;
}

.status-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
    font-size: 12px;
}

.status-label {
    color: #95a5a6;
}

.status-badge {
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

.status-badge.success {
    background: rgba(46, 204, 113, 0.2);
    color: #27ae60;
}

.status-text {
    color: #bdc3c7;
    font-weight: 600;
}

.copyright {
    text-align: center;
    color: #7f8c8d;
    font-size: 11px;
    padding-top: 10px;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

/* Scrollbar Styling */
.sidebar-nav::-webkit-scrollbar {
    width: 4px;
}

.sidebar-nav::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
}

.sidebar-nav::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 2px;
}

.sidebar-nav::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3);
}

/* Responsive Design */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
        overflow: hidden;
    }
    
    .sidebar:hover {
        width: 280px;
    }
    
    .profile-info,
    .profile-stats,
    .last-login span,
    .nav-section-title span,
    .nav-link span,
    .submenu,
    .sidebar-footer {
        display: none;
    }
    
    .sidebar:hover .profile-info,
    .sidebar:hover .profile-stats,
    .sidebar:hover .last-login span,
    .sidebar:hover .nav-section-title span,
    .sidebar:hover .nav-link span,
    .sidebar:hover .submenu,
    .sidebar:hover .sidebar-footer {
        display: block;
    }
    
    .sidebar:hover .submenu {
        display: block;
        max-height: 300px;
    }
    
    .nav-link {
        justify-content: center;
    }
    
    .sidebar:hover .nav-link {
        justify-content: flex-start;
    }
    
    .nav-link i {
        margin-right: 0;
    }
    
    .sidebar:hover .nav-link i {
        margin-right: 12px;
    }
}
</style>

<script>
// JavaScript for submenu toggle
document.addEventListener('DOMContentLoaded', function() {
    const submenuLinks = document.querySelectorAll('.nav-link.has-submenu');
    
    submenuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                return; // Don't toggle on mobile if sidebar is collapsed
            }
            
            e.preventDefault();
            const parent = this.parentElement;
            const isActive = parent.classList.contains('active');
            
            // Close all other submenus
            document.querySelectorAll('.nav-item.active').forEach(item => {
                if (item !== parent) {
                    item.classList.remove('active');
                }
            });
            
            // Toggle current submenu
            if (!isActive) {
                parent.classList.add('active');
            } else {
                parent.classList.remove('active');
            }
        });
    });
    
    // Auto-activate submenu if current page is in submenu
    const currentPage = window.location.pathname.split('/').pop();
    const submenuLinksArray = Array.from(submenuLinks);
    
    submenuLinksArray.forEach(link => {
        const submenu = link.nextElementSibling;
        if (submenu && submenu.classList.contains('submenu')) {
            const subLinks = submenu.querySelectorAll('a');
            subLinks.forEach(subLink => {
                const href = subLink.getAttribute('href');
                if (href && href.includes(currentPage)) {
                    link.parentElement.classList.add('active');
                }
            });
        }
    });
});
</script>