<footer class="footer" style="
    text-align: center; 
    font-size: 14px; 
    color: white;
    background-color: ; 
    position: relative; /* or 'fixed' for bottom of viewport */
    bottom: 0;
    width: 100%;
    padding: 15px 0;
    z-index: 1000; /* Ensures it's on top */
">
    <div class="footer-content">
        All Rights Reserved by Nigeria Immigration Service. Designed and Developed by
        <a href="https://www.immigration.gov.ng" style="color: white; text-decoration: underline;">NIS Web Team</a>.
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>