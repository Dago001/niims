<?php
require_once __DIR__ . '/config.php';

if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('loginUser')) {
    function loginUser($username, $password) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("
                SELECT u.id, u.username, u.password, u.full_name, r.name as role_name, r.id as role_id
                FROM users u
                LEFT JOIN roles r ON u.role_id = r.id 
                WHERE u.username = ?
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role_name'] = $user['role_name'];
                $_SESSION['role_id'] = $user['role_id'];
                
                // Update last login
                $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $updateStmt->execute([$user['id']]);
                
                return true;
            }
            return false;
        } catch (PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('logoutUser')) {
    function logoutUser() {
        session_start();
        session_unset();
        session_destroy();
        session_write_close();
        setcookie(session_name(),'',0,'/');
    }
}

if (!function_exists('createUser')) {
    function createUser($username, $password, $fullName, $roleId) {
        global $pdo;
        
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("
                INSERT INTO users (username, password, full_name, role_id)
                VALUES (?, ?, ?, ?)
            ");
            
            return $stmt->execute([$username, $hashedPassword, $fullName, $roleId]);
        } catch (PDOException $e) {
            error_log("Create user error: " . $e->getMessage());
            return false;
        }
    }
}

// NEW FUNCTIONS ADDED BELOW

if (!function_exists('getCurrentUserData')) {
    function getCurrentUserData() {
        global $pdo;
        
        if (!isset($_SESSION['user_id'])) {
            return [
                'username' => 'Guest',
                'full_name' => 'Guest User',
                'role_name' => 'Guest',
                'role_id' => null
            ];
        }
        
        try {
            $stmt = $pdo->prepare("
                SELECT u.*, r.name as role_name, r.id as role_id
                FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE u.id = ?
            ");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if (!$user) {
                return [
                    'username' => $_SESSION['username'] ?? 'User',
                    'full_name' => $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User',
                    'role_name' => $_SESSION['role_name'] ?? 'User',
                    'role_id' => $_SESSION['role_id'] ?? null
                ];
            }
            
            return $user;
        } catch (PDOException $e) {
            error_log("Error getting user data: " . $e->getMessage());
            return [
                'username' => $_SESSION['username'] ?? 'User',
                'full_name' => $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User',
                'role_name' => $_SESSION['role_name'] ?? 'User',
                'role_id' => $_SESSION['role_id'] ?? null
            ];
        }
    }
}

if (!function_exists('getSystemStats')) {
    function getSystemStats() {
        global $pdo;
        
        try {
            // Get total personnel count
            $personnelQuery = $pdo->query("SELECT COUNT(*) as count FROM tbl_emppersonal");
            $personnelResult = $personnelQuery ? $personnelQuery->fetch() : ['count' => 0];
            $totalPersonnel = $personnelResult['count'] ?? 0;
            
            // Get total users count
            $usersQuery = $pdo->query("SELECT COUNT(*) as count FROM users");
            $usersResult = $usersQuery ? $usersQuery->fetch() : ['count' => 0];
            $totalUsers = $usersResult['count'] ?? 0;
            
            return [
                'totalPersonnel' => $totalPersonnel,
                'totalUsers' => $totalUsers
            ];
        } catch (PDOException $e) {
            error_log("Error getting system stats: " . $e->getMessage());
            return [
                'totalPersonnel' => 0,
                'totalUsers' => 0
            ];
        }
    }
}

if (!function_exists('getUserById')) {
    function getUserById($user_id) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("
                SELECT u.*, r.name as role_name 
                FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE u.id = ?
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error getting user by ID: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('updateUserLastLogin')) {
    function updateUserLastLogin($user_id) {
        global $pdo;
        
        try {
            $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            return $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            error_log("Error updating last login: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('changeUserPassword')) {
    function changeUserPassword($user_id, $new_password) {
        global $pdo;
        
        try {
            $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            return $stmt->execute([$hashedPassword, $user_id]);
        } catch (PDOException $e) {
            error_log("Error changing password: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('checkUsernameExists')) {
    function checkUsernameExists($username, $exclude_user_id = null) {
        global $pdo;
        
        try {
            if ($exclude_user_id) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
                $stmt->execute([$username, $exclude_user_id]);
            } else {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->execute([$username]);
            }
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("Error checking username: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('checkEmailExists')) {
    function checkEmailExists($email, $exclude_user_id = null) {
        global $pdo;
        
        try {
            if ($exclude_user_id) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$email, $exclude_user_id]);
            } else {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
            }
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("Error checking email: " . $e->getMessage());
            return false;
        }
    }
}

// Helper function to automatically set sidebar variables
if (!function_exists('prepareSidebarData')) {
    function prepareSidebarData() {
        global $user, $totalPersonnel, $totalUsers;
        
        // Get user data if not already set
        if (!isset($user) || !is_array($user)) {
            $user = getCurrentUserData();
        }
        
        // Get system stats if not already set
        if (!isset($totalPersonnel)) {
            $stats = getSystemStats();
            $totalPersonnel = $stats['totalPersonnel'];
        }
        
        if (!isset($totalUsers)) {
            $stats = getSystemStats();
            $totalUsers = $stats['totalUsers'];
        }
    }
}

// createUser('newuser', 'password123', 'New User Full Name', 1); // 1 is admin role_id
?>