<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <title>NIS Personnel Posting Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { 
            padding-top: 0 !important;
            margin: 0 !important;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .top-header {
            background-color: #004d40;
            padding: 0.3rem 0;  /* Reduced container padding */
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .top-header .container-fluid {
            padding-left: 0.5rem;  /* Reduced container spacing */
            padding-right: 0.5rem;
        }
        .top-header .logo-container img {
            height: 70px;
            width: auto;
            transition: transform 0.3s ease;
        }
        .top-header .logo-container img:hover {
            transform: scale(1.05);
        }
        .system-title {
            color: white;
            font-size: 1.8rem;
            margin: 0;
            font-weight: 600;
            text-align: center;
            flex-grow: 1;
        }
        .logo-container.me-3 {
            margin-right: 0.5rem !important;  /* Reduced margin between logo and title */
        }
        .d-flex.justify-content-between {
            gap: 0.5rem;  /* Added small gap between flex items */
        }
        .header-nav {
            display: flex;
            gap: 0.5rem;  /* Reduced gap between nav items */
            align-items: center;
            margin-left: 0.5rem;  /* Added small margin to separate from title */
        }
        .header-nav a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            font-weight: 500;
        }
        .header-nav a:hover {
            background-color: rgba(255,255,255,0.1);
        }
        .header-nav a.active {
            background-color: rgba(255,255,255,0.2);
        }
        @media (max-width: 768px) {
            .system-title {
                font-size: 1.4rem;
            }
            .header-nav {
                gap: 0.5rem;
            }
            .header-nav a {
                padding: 0.4rem 0.8rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="top-header">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div class="logo-container me-3">
                    <img src="assets/images/logo.png" alt="NIS Logo">
                </div>
                <h1 class="system-title">NIS Personnel Posting Management System</h1>
                <div class="header-nav">
                    <?php if (isLoggedIn()): ?>
                        <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                            <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                        </a>
                        <a href="edit_profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'edit_profile.php' ? 'active' : ''; ?>">
                            <i class="fas fa-user me-1"></i> Profile
                        </a>
                        <a href="logout.php" class="text-danger">
                            <i class="fas fa-sign-out-alt me-1"></i> Logout
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>