<?php
// Function to check if user has a specific permission
function hasPermission($permission_name) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    // Get user's role from the session
    $role_id = $_SESSION['role_id'] ?? null;
    
    if (!$role_id) {
        return false;
    }
    
    global $pdo;
    
    try {
        // For admin users, always return true (bypass permission check)
        if (isset($_SESSION['role_name']) && strtolower($_SESSION['role_name']) === 'admin') {
            return true;
        }
        
        // Check if the user's role has this permission
        $stmt = $pdo->prepare("
            SELECT 1 
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role_id = ? AND p.name = ?
        ");
        $stmt->execute([$role_id, $permission_name]);
        
        return $stmt->fetch() !== false;
    } catch (PDOException $e) {
        // Log error for debugging
        error_log("Permission check error: " . $e->getMessage());
        
        // For development, you might want to return true temporarily
        // return true; // Uncomment this for testing
        
        // For production, return false
        return false;
    }
}

// Alternative: Check multiple permissions at once
function hasAnyPermission($permissions = []) {
    foreach ($permissions as $permission) {
        if (hasPermission($permission)) {
            return true;
        }
    }
    return false;
}

// Check if user has all specified permissions
function hasAllPermissions($permissions = []) {
    foreach ($permissions as $permission) {
        if (!hasPermission($permission)) {
            return false;
        }
    }
    return true;
}

// NEW ZONE-BASED PERMISSION FUNCTIONS

// Check if user is Super Admin
function isSuperAdmin() {
    if (!isset($_SESSION['user_id'])) return false;
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT r.name 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ? AND r.name = 'Super Admin'
        ");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("isSuperAdmin check error: " . $e->getMessage());
        return false;
    }
}

// Check if user is Service HQ
function isServiceHQ() {
    if (!isset($_SESSION['user_id'])) return false;
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT r.name 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ? AND (r.name = 'Service HQ' OR r.name = 'Service Headquarters')
        ");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("isServiceHQ check error: " . $e->getMessage());
        return false;
    }
}

// Check if user is Zone Admin
function isZoneAdmin() {
    if (!isset($_SESSION['user_id'])) return false;
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT r.name 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ? AND r.name LIKE '%Zone%Admin%'
        ");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("isZoneAdmin check error: " . $e->getMessage());
        return false;
    }
}

// Check if user is any type of Zone user (Admin or regular)
function isZoneUser() {
    if (!isset($_SESSION['user_id'])) return false;
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT r.name 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ? AND (r.name LIKE '%Zone%' OR r.name LIKE 'Zone %')
        ");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("isZoneUser check error: " . $e->getMessage());
        return false;
    }
}

// Get zones assigned to a user
function getUserZones($user_id) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT z.id, z.zone_name, z.zone_code 
            FROM user_zones uz 
            JOIN zones z ON uz.zone_id = z.id 
            WHERE uz.user_id = ?
            ORDER BY z.zone_name
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("getUserZones error: " . $e->getMessage());
        return [];
    }
}

// Check if user can modify another user
function canModifyUser($current_user_id, $target_user_id) {
    if ($current_user_id == $target_user_id) return false; // Can't modify self
    
    global $pdo;
    
    try {
        // Get current user's role
        $stmt = $pdo->prepare("
            SELECT r.name 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$current_user_id]);
        $current_role = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$current_role) return false;
        
        // Get target user's role
        $stmt->execute([$target_user_id]);
        $target_role = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$target_role) return false;
        
        // Super Admin can modify anyone
        if ($current_role['name'] === 'Super Admin') return true;
        
        // Service HQ can modify Zone Admins and regular users, but not other Service HQ or Super Admins
        if ($current_role['name'] === 'Service HQ' || $current_role['name'] === 'Service Headquarters') {
            if ($target_role['name'] === 'Super Admin' || 
                $target_role['name'] === 'Service HQ' || 
                $target_role['name'] === 'Service Headquarters') {
                return false;
            }
            return true;
        }
        
        // Zone Admin can only modify users in their zones
        if (strpos($current_role['name'], 'Zone') !== false) {
            // Check if both users share at least one zone
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as count
                FROM user_zones uz1
                JOIN user_zones uz2 ON uz1.zone_id = uz2.zone_id
                WHERE uz1.user_id = ? AND uz2.user_id = ?
            ");
            $stmt->execute([$current_user_id, $target_user_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result && $result['count'] > 0;
        }
        
        return false;
    } catch (PDOException $e) {
        error_log("canModifyUser error: " . $e->getMessage());
        return false;
    }
}

// Check if current user can access a specific zone
function canAccessZone($zone_id) {
    if (!isset($_SESSION['user_id'])) return false;
    
    // Super Admin and Service HQ can access all zones
    if (isSuperAdmin() || isServiceHQ()) {
        return true;
    }
    
    global $pdo;
    try {
        // Check if user is assigned to this zone
        $stmt = $pdo->prepare("
            SELECT 1 
            FROM user_zones 
            WHERE user_id = ? AND zone_id = ?
        ");
        $stmt->execute([$_SESSION['user_id'], $zone_id]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("canAccessZone error: " . $e->getMessage());
        return false;
    }
}

// Get user's accessible zones (for dropdowns/filters)
function getUserAccessibleZones() {
    if (!isset($_SESSION['user_id'])) return [];
    
    global $pdo;
    
    try {
        if (isSuperAdmin() || isServiceHQ()) {
            // Return all zones
            $stmt = $pdo->prepare("SELECT id, zone_name, zone_code FROM zones ORDER BY zone_name");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // Return only user's assigned zones
            return getUserZones($_SESSION['user_id']);
        }
    } catch (PDOException $e) {
        error_log("getUserAccessibleZones error: " . $e->getMessage());
        return [];
    }
}

// Log activity
function logActivity($action) {
    if (!isset($_SESSION['user_id'])) return false;
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_id, action, ip_address, user_agent)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $action,
            $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
        ]);
        return true;
    } catch (PDOException $e) {
        error_log("logActivity error: " . $e->getMessage());
        return false;
    }
}

// Check if user can manage personnel in a specific zone
function canManageZonePersonnel($zone_id = null) {
    if (!isset($_SESSION['user_id'])) return false;
    
    // Super Admin and Service HQ can manage all zones
    if (isSuperAdmin() || isServiceHQ()) {
        return true;
    }
    
    // Zone Admins can only manage their assigned zones
    if (isZoneAdmin() || isZoneUser()) {
        if ($zone_id === null) {
            // If no specific zone, check if they have any zones
            $userZones = getUserZones($_SESSION['user_id']);
            return !empty($userZones);
        } else {
            // Check specific zone
            return canAccessZone($zone_id);
        }
    }
    
    return false;
}

// Get user's role name
function getUserRoleName($user_id = null) {
    if ($user_id === null && !isset($_SESSION['user_id'])) {
        return 'Unknown';
    }
    
    $target_user_id = $user_id ?? $_SESSION['user_id'];
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT r.name 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$target_user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result ? $result['name'] : 'Unknown';
    } catch (PDOException $e) {
        error_log("getUserRoleName error: " . $e->getMessage());
        return 'Unknown';
    }
}
?>