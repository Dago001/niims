<?php
// Start session and include config
session_start();
require_once 'includes/config.php';

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$search_results = [];
$search_performed = false;
$all_personnel = [];
$error = '';
$posting_history = [];
$current_posting_data = null;

// Database configuration for current_posting table
$db_config = [
    'niimscom_idcard' => [
        'host' => 'localhost',
        'dbname' => 'niimscom_idcard',
        'username' => 'niimscom_admin',
        'password' => '$@muel@0deh'
    ]
];

// Get user information for sidebar
$user = [];
$totalPersonnel = 0;
$totalUsers = 0;

try {
    // Get user information
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("
            SELECT u.*, r.name as role_name
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    }

    // Get statistics for sidebar
    $totalPersonnel = $pdo->query("SELECT COUNT(*) as count FROM tbl_emppersonal")->fetch()['count'];
    $totalUsers = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];

} catch (Exception $e) {
    error_log("Error getting user/sidebar data: " . $e->getMessage());
}

// Set safe defaults for user data
if (empty($user)) {
    $user = [
        'username' => $_SESSION['username'] ?? 'User',
        'full_name' => $_SESSION['username'] ?? 'User',
        'role_name' => 'User'
    ];
}

// Initialize pdo_idcard variable
$pdo_idcard = null;

// Create database connection for current_posting table
try {
    $pdo_idcard = new PDO(
        "mysql:host={$db_config['niimscom_idcard']['host']};dbname={$db_config['niimscom_idcard']['dbname']};charset=utf8mb4",
        $db_config['niimscom_idcard']['username'],
        $db_config['niimscom_idcard']['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Create posting_history table if it doesn't exist
    $createHistoryTableSQL = "
        CREATE TABLE IF NOT EXISTS `posting_history` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `serviceNo` VARCHAR(50) NOT NULL,
            `posting_location` TEXT NOT NULL,
            `posting_date` DATE NOT NULL,
            `posting_type` ENUM('initial', 'transfer', 'current') DEFAULT 'transfer',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX `idx_serviceNo` (`serviceNo`),
            INDEX `idx_posting_date` (`posting_date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    $pdo_idcard->exec($createHistoryTableSQL);
    
} catch (PDOException $e) {
    // Continue without posting history if table creation fails
    error_log("Error connecting to niimscom_idcard database: " . $e->getMessage());
    $pdo_idcard = null;
}

// Define sanitizeInput function if not already defined
if (!function_exists('sanitizeInput')) {
    function sanitizeInput($data) {
        if (is_null($data)) return '';
        return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
}

// Initialize pagination variables
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$totalRecords = 0;
$totalPages = 1;

if (isset($_GET['serviceNo'])) {
    $serviceNo = sanitizeInput($_GET['serviceNo']);
    $search_performed = true;
    
    try {
        // Search using serviceNo column from both tables
        $stmt = $pdo->prepare("
            SELECT 
                e.serviceNo,
                e.dofa,
                e.dopa,
                e.presentPosting,
                e.currentRank,
                e.empStatus,
                p.surname,
                p.firstName,
                p.middleName
            FROM tbl_employment e
            INNER JOIN tbl_emppersonal p ON e.serviceNo = p.serviceNo
            WHERE e.serviceNo = ?
            LIMIT 1
        ");
        $stmt->execute([$serviceNo]);
        $personnel = $stmt->fetch();
        
        if ($personnel) {
            $search_results = [
                'personnel' => $personnel
            ];
            
            // Fetch current posting from current_posting table
            if ($pdo_idcard) {
                try {
                    $currentStmt = $pdo_idcard->prepare("
                        SELECT posting_location, updated_at 
                        FROM current_posting 
                        WHERE serviceNo = ?
                        LIMIT 1
                    ");
                    $currentStmt->execute([$serviceNo]);
                    $current_posting_data = $currentStmt->fetch();
                    
                    // Fetch posting history
                    $historyStmt = $pdo_idcard->prepare("
                        SELECT posting_location, posting_date, posting_type, created_at
                        FROM posting_history 
                        WHERE serviceNo = ? 
                        ORDER BY posting_date DESC, created_at DESC
                        LIMIT 50
                    ");
                    $historyStmt->execute([$serviceNo]);
                    $posting_history = $historyStmt->fetchAll();
                    
                    // If no history exists but we have current posting, create initial history entry
                    if (empty($posting_history) && $current_posting_data) {
                        try {
                            $initialStmt = $pdo_idcard->prepare("
                                INSERT INTO posting_history (serviceNo, posting_location, posting_date, posting_type)
                                VALUES (?, ?, CURDATE(), 'initial')
                            ");
                            $initialStmt->execute([$serviceNo, $current_posting_data['posting_location']]);
                            
                            // Re-fetch history
                            $historyStmt->execute([$serviceNo]);
                            $posting_history = $historyStmt->fetchAll();
                        } catch (PDOException $e) {
                            error_log("Error creating initial history: " . $e->getMessage());
                        }
                    }
                    
                } catch (PDOException $e) {
                    // Silently continue if current_posting table doesn't exist yet
                    error_log("Error fetching posting data: " . $e->getMessage());
                }
            }
        }
    } catch (PDOException $e) {
        $error = "Error searching for record: " . $e->getMessage();
        error_log("Search error: " . $e->getMessage());
    }
} elseif (!isset($_GET['serviceNo']) && $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Display all records from both tables with pagination
    
    try {
        // Get total count for pagination
        $countStmt = $pdo->query("
            SELECT COUNT(*) as total 
            FROM tbl_employment e
            INNER JOIN tbl_emppersonal p ON e.serviceNo = p.serviceNo
        ");
        $countResult = $countStmt->fetch();
        $totalRecords = $countResult ? $countResult['total'] : 0;
        $totalPages = ceil($totalRecords / $limit);
        
        // Fetch paginated records
        $stmt = $pdo->prepare("
            SELECT 
                e.serviceNo,
                e.dofa,
                e.dopa,
                e.presentPosting,
                e.currentRank,
                e.empStatus,
                p.surname,
                p.firstName,
                p.middleName
            FROM tbl_employment e
            INNER JOIN tbl_emppersonal p ON e.serviceNo = p.serviceNo
            ORDER BY e.serviceNo ASC
            LIMIT ? OFFSET ?
        ");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        $all_personnel = $stmt->fetchAll();
        
        // Get all service numbers for batch query
        $serviceNumbers = [];
        foreach ($all_personnel as $person) {
            if (isset($person['serviceNo'])) {
                $serviceNumbers[] = $person['serviceNo'];
            }
        }
        
        // Batch fetch current postings in ONE query instead of N queries
        $current_locations = [];
        if ($pdo_idcard && !empty($serviceNumbers)) {
            try {
                // Create placeholders for IN clause
                $placeholders = str_repeat('?,', count($serviceNumbers) - 1) . '?';
                
                $currentStmt = $pdo_idcard->prepare("
                    SELECT serviceNo, posting_location 
                    FROM current_posting 
                    WHERE serviceNo IN ($placeholders)
                ");
                $currentStmt->execute($serviceNumbers);
                $current_postings = $currentStmt->fetchAll();
                
                // Create associative array for easy access
                foreach ($current_postings as $posting) {
                    $current_locations[$posting['serviceNo']] = $posting['posting_location'];
                }
                
            } catch (PDOException $e) {
                error_log("Error batch fetching current postings: " . $e->getMessage());
            }
        }
        
        // Assign current locations to personnel
        foreach ($all_personnel as &$person) {
            if (isset($person['serviceNo']) && isset($current_locations[$person['serviceNo']])) {
                $person['current_location'] = $current_locations[$person['serviceNo']];
            } else {
                $person['current_location'] = $person['presentPosting'] ?? 'N/A';
            }
        }
        unset($person); // Unset reference
        
    } catch (PDOException $e) {
        $error = "Error loading records: " . $e->getMessage();
        error_log("Database error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIS Personnel Posting Management System - Search</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* All existing CSS remains the same... */
        /* CSS Reset */
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        /* Body styling */
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: 
                linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(39, 174, 96, 0.9) 100%),
                url('assets/images/tech_building.jpg') center/cover no-repeat fixed;
            min-height: 100vh;
            color: #333;
        }
        
        /* Header styling */
        .header-container {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 0.8rem 2rem;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(5px);
            border-bottom: 2px solid #27ae60;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .logo-title-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .header-logo {
            height: 50px;
            width: auto;
            object-fit: contain;
        }
        
        /* REDUCED: system-title font size */
        .system-title {
            color: #2c3e50;
            font-size: 1.2rem; /* Reduced from 1.4rem */
            font-weight: 800;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-profile {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        /* Main layout with sidebar */
        .main-layout {
            display: flex;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            gap: 20px;
            min-height: calc(100vh - 80px);
        }
        
        /* Sidebar styling */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
            color: #ecf0f1;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
            z-index: 100;
            flex-shrink: 0;
        }
        
        /* Content area styling */
        .content-area {
            flex: 1;
            background: rgba(255, 255, 255, 0.98);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            padding: 2rem;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(39, 174, 96, 0.1);
            overflow-x: auto;
        }
        
        /* BACK BUTTON STYLES */
        .back-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .back-btn:hover {
            background: #5a6268;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(108, 117, 125, 0.3);
        }
        
        /* Page header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        /* REDUCED: page-title font size */
        .page-title {
            color: #2c3e50;
            font-size: 1.5rem; /* Reduced from 1.8rem */
            font-weight: 700;
            margin: 0;
        }
        
        /* Search form */
        .search-form {
            display: flex;
            gap: 0.5rem;
            flex: 1;
            max-width: 400px;
        }
        
        /* REDUCED: search-input font size */
        .search-input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 0.9rem; /* Reduced from 1rem */
            transition: all 0.3s ease;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #27ae60;
            box-shadow: 0 0 0 3px rgba(39, 174, 96, 0.2);
        }
        
        /* REDUCED: search-btn font size */
        .search-btn {
            background: #27ae60;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-size: 0.9rem; /* Reduced from 1rem */
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .search-btn:hover {
            background: #219a52;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(39, 174, 96, 0.3);
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
            overflow: hidden;
            border: 1px solid rgba(39, 174, 96, 0.1);
        }
        
        /* REDUCED: card-header font size */
        .card-header {
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            color: white;
            padding: 1.2rem 1.5rem;
            font-weight: 600;
            font-size: 1rem; /* Reduced from 1.2rem */
            border: none;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* Tables */
        .table-responsive {
            overflow-x: auto;
            margin: -1.5rem;
            padding: 1.5rem;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        /* REDUCED: table thead th font size */
        .table thead th {
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            color: white;
            padding: 0.8rem; /* Reduced from 1rem */
            text-align: left;
            font-weight: 600;
            border: none;
            position: sticky;
            top: 0;
            z-index: 1;
        }
        
        .table tbody tr {
            border-bottom: 1px solid #eee;
            transition: background-color 0.2s ease;
        }
        
        .table tbody tr:hover {
            background-color: rgba(39, 174, 96, 0.05);
        }
        
        /* REDUCED: table tbody td font size and padding */
        .table tbody td {
            padding: 0.8rem; /* Reduced from 1rem */
            vertical-align: middle;
            font-size: 0.9rem; /* Added */
        }
        
        /* Info boxes */
        .personal-info, .employment-info {
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        
        .personal-info {
            background: rgba(39, 174, 96, 0.05);
            border-left: 4px solid #27ae60;
        }
        
        .employment-info {
            background: rgba(52, 152, 219, 0.05);
            border-left: 4px solid #3498db;
        }
        
        /* REDUCED: info-title font size */
        .info-title {
            color: #2c3e50;
            font-size: 1.1rem; /* Reduced from 1.3rem */
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        /* Status badges */
        .status-active {
            color: #27ae60;
            font-weight: 600;
            background: rgba(39, 174, 96, 0.1);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            display: inline-block;
            font-size: 0.85rem; /* Added */
        }
        
        .status-inactive {
            color: #e74c3c;
            font-weight: 600;
            background: rgba(231, 76, 60, 0.1);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            display: inline-block;
            font-size: 0.85rem; /* Added */
        }
        
        .status-pending {
            color: #f39c12;
            font-weight: 600;
            background: rgba(243, 156, 18, 0.1);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            display: inline-block;
            font-size: 0.85rem; /* Added */
        }
        
        /* Buttons */
        .btn-group {
            display: flex;
            gap: 0.5rem;
        }
        
        /* REDUCED: btn font size */
        .btn {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.85rem; /* Reduced from 0.9rem */
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(108, 117, 125, 0.3);
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2980b9;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(52, 152, 219, 0.3);
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(23, 162, 184, 0.3);
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #219a52;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(39, 174, 96, 0.3);
        }
        
        .btn-warning {
            background: #f39c12;
            color: white;
        }
        
        .btn-warning:hover {
            background: #d68910;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(243, 156, 18, 0.3);
        }
        
        .btn-light {
            background: #f8f9fa;
            color: #333;
            border: 1px solid #ddd;
        }
        
        .btn-light:hover {
            background: #e9ecef;
            color: #333;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        /* NEW: Print Button Styling */
        .btn-print {
            background: #9c27b0;
            color: white;
        }
        
        .btn-print:hover {
            background: #7b1fa2;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(156, 39, 176, 0.3);
        }
        
        /* Pagination styles */
        .pagination {
            display: flex;
            justify-content: center;
            margin: 2rem 0 1rem;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        
        .page-link {
            padding: 0.5rem 1rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
            background: white;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .page-link:hover {
            background: #27ae60;
            color: white;
            border-color: #27ae60;
        }
        
        .page-link.active {
            background: #27ae60;
            color: white;
            border-color: #27ae60;
        }
        
        .page-info {
            text-align: center;
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }
        
        /* Loading spinner */
        .loading-spinner {
            display: none;
            text-align: center;
            padding: 2rem;
        }
        
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #27ae60;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Alerts */
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 0.9rem; /* Added */
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #721c24;
            border-left-color: #dc3545;
        }
        
        .alert-warning {
            background: rgba(255, 193, 7, 0.1);
            color: #856404;
            border-left-color: #ffc107;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 1rem;
        }
        
        /* Additional styles for posting history */
        .posting-history-container {
            background: rgba(155, 89, 182, 0.05);
            border-left: 4px solid #9b59b6;
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        
        .history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        /* REDUCED: history-table th font size and padding */
        .history-table th {
            background: rgba(155, 89, 182, 0.1);
            padding: 0.7rem; /* Reduced from 0.8rem */
            text-align: left;
            font-weight: 600;
            color: #7d3c98;
            border: none;
            font-size: 0.9rem; /* Added */
        }
        
        /* REDUCED: history-table td font size and padding */
        .history-table td {
            padding: 0.7rem; /* Reduced from 0.8rem */
            border-bottom: 1px solid #e0e0e0;
            vertical-align: middle;
            font-size: 0.9rem; /* Added */
        }
        
        .history-table tr:hover {
            background: rgba(155, 89, 182, 0.03);
        }
        
        .current-posting {
            background: rgba(39, 174, 96, 0.1);
            padding: 0.8rem 1.2rem;
            border-radius: 8px;
            font-weight: 600;
            color: #27ae60;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem; /* Added */
        }
        
        .location-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.8rem;
            background: #e8f5e9;
            color: #2e7d32;
            border-radius: 12px;
            font-size: 0.8rem; /* Reduced from 0.85rem */
            margin: 0.2rem 0.3rem;
            white-space: nowrap;
        }
        
        .location-match {
            background: #d4edda;
            color: #155724;
        }
        
        .location-mismatch {
            background: #fff3cd;
            color: #856404;
        }
        
        .badge {
            display: inline-block;
            padding: 0.25em 0.4em;
            font-size: 70%; /* Reduced from 75% */
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }
        
        .bg-primary { background-color: #007bff !important; }
        .bg-success { background-color: #28a745 !important; }
        .bg-info { background-color: #17a2b8 !important; }
        .bg-secondary { background-color: #6c757d !important; }
        
        /* Grid layouts */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }
        
        .current-location-box {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.1) 0%, rgba(46, 204, 113, 0.1) 100%);
            border: 2px solid #27ae60;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .current-location-box h4 {
            color: #27ae60;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1rem; /* Added */
        }
        
        /* Responsive Design */
        @media (max-width: 992px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
            
            .logo-title-container {
                width: 100%;
                justify-content: space-between;
            }
            
            .user-info {
                width: 100%;
                justify-content: flex-end;
            }
            
            .main-layout {
                flex-direction: column;
                padding: 15px;
            }
            
            .sidebar {
                width: 100%;
                max-height: 400px;
                overflow-y: auto;
            }
            
            .content-area {
                padding: 1.5rem;
            }
            
            .page-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-form {
                max-width: 100%;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            body {
                padding: 0;
            }
            
            .header-container {
                padding: 0.8rem 1rem;
            }
            
            .header-logo {
                height: 40px;
            }
            
            /* REDUCED: system-title font size for mobile */
            .system-title {
                font-size: 1rem; /* Reduced from 1.1rem */
            }
            
            .main-layout {
                padding: 10px;
            }
            
            .content-area {
                padding: 1.2rem;
            }
            
            /* REDUCED: page-title font size for mobile */
            .page-title {
                font-size: 1.3rem; /* Reduced from 1.5rem */
            }
            
            .card-body {
                padding: 1.2rem;
            }
            
            .table-responsive {
                margin: -1.2rem;
                padding: 1.2rem;
            }
            
            .table thead th, .table tbody td {
                padding: 0.8rem;
            }
            
            /* REDUCED: info-title font size for mobile */
            .info-title {
                font-size: 1rem; /* Reduced from 1.1rem */
            }
            
            /* REDUCED: btn font size for mobile */
            .btn {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem; /* Reduced from 0.85rem */
            }
            
            .back-btn {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem; /* Reduced from 0.85rem */
            }
            
            .current-location-box {
                padding: 1rem;
            }
            
            .posting-history-container {
                padding: 1rem;
            }
            
            /* REDUCED: history-table font size for mobile */
            .history-table th, .history-table td {
                padding: 0.6rem;
                font-size: 0.85rem; /* Reduced from 0.9rem */
            }
        }
        
        @media (max-width: 576px) {
            .header-content {
                flex-direction: column;
                align-items: stretch;
            }
            
            .logo-title-container {
                flex-direction: column;
                align-items: center;
                text-align: center;
                gap: 0.5rem;
            }
            
            /* REDUCED: system-title font size for small screens */
            .system-title {
                font-size: 0.9rem; /* Reduced from 1rem */
            }
            
            .user-info {
                justify-content: center;
                margin-top: 0.5rem;
            }
            
            .content-area {
                padding: 1rem;
            }
            
            .page-header {
                gap: 1rem;
            }
            
            .search-form {
                flex-direction: column;
            }
            
            .search-input {
                width: 100%;
            }
            
            .search-btn {
                width: 100%;
                justify-content: center;
            }
            
            /* REDUCED: table font size for small screens */
            .table {
                font-size: 0.85rem; /* Reduced from 0.9rem */
            }
            
            .table thead th, .table tbody td {
                padding: 0.6rem;
            }
            
            .btn-group {
                flex-direction: column;
                gap: 0.3rem;
            }
            
            .btn-group .btn {
                width: 100%;
                justify-content: center;
            }
            
            .personal-info, .employment-info {
                padding: 1rem;
            }
            
            .history-table {
                display: block;
                overflow-x: auto;
            }
            
            .btn-group {
                flex-wrap: wrap;
            }
        }
        
        @media (max-width: 400px) {
            /* REDUCED: page-title font size for extra small screens */
            .page-title {
                font-size: 1.1rem; /* Reduced from 1.3rem */
            }
            
            /* REDUCED: table font size for extra small screens */
            .table {
                font-size: 0.8rem; /* Reduced from 0.85rem */
            }
            
            /* REDUCED: btn font size for extra small screens */
            .btn {
                font-size: 0.75rem; /* Reduced from 0.8rem */
                padding: 0.4rem 0.6rem;
            }
            
            .back-btn {
                font-size: 0.75rem; /* Reduced from 0.8rem */
                padding: 0.4rem 0.6rem;
            }
        }
        
        /* Print-specific styles */
        @media print {
            body * {
                visibility: hidden;
            }
            
            .printable-area, .printable-area * {
                visibility: visible;
            }
            
            .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
                background: white;
            }
            
            .no-print {
                display: none !important;
            }
            
            .btn, .search-form, .header-container, .page-header .search-form {
                display: none !important;
            }
            
            .card {
                box-shadow: none;
                border: 1px solid #ddd;
            }
            
            .table {
                page-break-inside: avoid;
            }
            
            .page-break {
                page-break-before: always;
            }
            
            /* Hide non-essential elements for printing */
            .current-location-box {
                background: white;
                border: 2px solid #000;
                color: black;
            }
            
            .current-posting {
                background: white;
                color: black;
                border: 1px solid #000;
            }
            
            .personal-info, .employment-info, .posting-history-container {
                background: white;
                border-left: 4px solid #000;
                color: black;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header-container">
        <div class="header-content">
            <div class="logo-title-container">
                <img src="assets/images/logo.png" alt="NIS Logo" class="header-logo">
                <h1 class="system-title">NIS Personnel Posting Management System</h1>
            </div>
            <div class="user-info">
                <div class="user-profile">
                    <?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?>
                </div>
                <div style="font-size: 0.9rem;"> <!-- Added font-size -->
                    <strong><?php echo htmlspecialchars($user['full_name'] ?? $user['username'] ?? 'User'); ?></strong><br>
                    <small><?php echo htmlspecialchars($user['role_name'] ?? 'User'); ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Layout with Sidebar -->
    <div class="main-layout">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- Main Content Area -->
        <div class="content-area">
            <!-- Page Header -->
            <div class="page-header">
                <h2 class="page-title">Personnel Records</h2>
                <form class="search-form" action="search.php" method="GET">
                    <input type="text" class="search-input" placeholder="Search by Service Number" name="serviceNo" 
                           value="<?php echo isset($_GET['serviceNo']) ? htmlspecialchars($_GET['serviceNo']) : ''; ?>">
                    <button class="search-btn" type="submit">
                        <i class="fas fa-search"></i> Search
                    </button>
                </form>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($search_performed && empty($search_results)): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> No records found for Service Number: <?php echo htmlspecialchars($_GET['serviceNo'] ?? ''); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($search_results)): ?>
                <!-- Single Record View -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-user-tie"></i> Personnel Details - <?php echo htmlspecialchars($search_results['personnel']['serviceNo'] ?? ''); ?>
                    </div>
                    <div class="card-body">
                        <!-- Current Location Display -->
                        <div class="current-location-box">
                            <h4>
                                <i class="fas fa-map-marker-alt"></i> Current Posting Location
                            </h4>
                            <?php if ($current_posting_data): ?>
                                <div class="current-posting">
                                    <i class="fas fa-check-circle"></i>
                                    <strong><?php echo htmlspecialchars($current_posting_data['posting_location'] ?? ''); ?></strong>
                                </div>
                                <div style="font-size: 0.85rem; color: #666; display: flex; align-items: center; gap: 0.5rem;"> <!-- Reduced font-size -->
                                    <i class="fas fa-clock"></i> Last updated: <?php echo $current_posting_data['updated_at'] ?? 'N/A'; ?>
                                </div>
                            <?php else: ?>
                                <div class="current-posting" style="background: rgba(231, 76, 60, 0.1); color: #e74c3c;">
                                    <i class="fas fa-exclamation-circle"></i>
                                    <strong>Current posting not initiated </strong>
                                </div>
                                <div style="font-size: 0.85rem; color: #666; display: flex; align-items: center; gap: 0.5rem;"> <!-- Reduced font-size -->
                                    <i class="fas fa-info-circle"></i> Using employment record: <?php echo htmlspecialchars($search_results['personnel']['presentPosting'] ?? 'N/A'); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Personal Information -->
                        <div class="personal-info">
                            <h3 class="info-title">
                                <i class="fas fa-user"></i> Personal Information
                            </h3>
                            <div class="info-grid">
                                <div>
                                    <table class="table" style="background: transparent; border: none;">
                                        <tr>
                                            <th width="40%">Service Number</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['serviceNo'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Surname</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['surname'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>First Name</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['firstName'] ?? 'N/A'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div>
                                    <table class="table" style="background: transparent; border: none;">
                                        <tr>
                                            <th width="40%">Middle Name</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['middleName'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Full Name</th>
                                            <td>
                                                <strong>
                                                    <?php 
                                                    echo htmlspecialchars($search_results['personnel']['surname'] ?? '') . ' ' . 
                                                         htmlspecialchars($search_results['personnel']['firstName'] ?? '') . ' ' . 
                                                         htmlspecialchars($search_results['personnel']['middleName'] ?? '');
                                                    ?>
                                                </strong>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Employment Information -->
                        <div class="employment-info">
                            <h3 class="info-title">
                                <i class="fas fa-briefcase"></i> Employment Information
                            </h3>
                            <div class="info-grid">
                                <div>
                                    <table class="table" style="background: transparent; border: none;">
                                        <tr>
                                            <th width="40%">Current Rank</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['currentRank'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date of First Appointment</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['dofa'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date of Present Appointment</th>
                                            <td><?php echo htmlspecialchars($search_results['personnel']['dopa'] ?? 'N/A'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div>
                                    <table class="table" style="background: transparent; border: none;">
                                        <tr>
                                            <th width="40%">Original Posting (Employment Record)</th>
                                            <td>
                                                <?php echo htmlspecialchars($search_results['personnel']['presentPosting'] ?? 'N/A'); ?>
                                                <?php if ($current_posting_data && ($search_results['personnel']['presentPosting'] ?? '') !== ($current_posting_data['posting_location'] ?? '')): ?>
                                                    <span class="location-badge location-mismatch" style="margin-left: 0.5rem;">
                                                        <i class="fas fa-exclamation-triangle"></i> Mismatch
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Employment Status</th>
                                            <td>
                                                <?php 
                                                $status = $search_results['personnel']['empStatus'] ?? 'N/A';
                                                $status_class = '';
                                                if (strtolower($status) === 'active') {
                                                    $status_class = 'status-active';
                                                } elseif (strtolower($status) === 'inactive') {
                                                    $status_class = 'status-inactive';
                                                } elseif (strtolower($status) === 'pending') {
                                                    $status_class = 'status-pending';
                                                }
                                                ?>
                                                <span class="<?php echo $status_class; ?>">
                                                    <?php echo htmlspecialchars($status); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Posting History -->
                        <div class="posting-history-container">
                            <h3 class="info-title">
                                <i class="fas fa-history"></i> Posting History
                            </h3>
                            <?php if (!empty($posting_history)): ?>
                                <div class="table-responsive" style="margin: 0; padding: 0;">
                                    <table class="history-table">
                                        <thead>
                                            <tr>
                                                <th>Posting Location</th>
                                                <th>Posting Date</th>
                                                <th>Type</th>
                                                <th>Recorded On</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($posting_history as $history): ?>
                                                <tr>
                                                    <td>
                                                        <?php echo htmlspecialchars($history['posting_location'] ?? ''); ?>
                                                        <?php if ($current_posting_data && ($history['posting_location'] ?? '') === ($current_posting_data['posting_location'] ?? '')): ?>
                                                            <span class="location-badge location-match">
                                                                <i class="fas fa-check"></i> Current
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo $history['posting_date'] ?? ''; ?></td>
                                                    <td>
                                                        <?php 
                                                        $type_badge = '';
                                                        switch($history['posting_type'] ?? '') {
                                                            case 'initial': $type_badge = 'bg-primary'; break;
                                                            case 'transfer': $type_badge = 'bg-info'; break;
                                                            case 'current': $type_badge = 'bg-success'; break;
                                                            default: $type_badge = 'bg-secondary';
                                                        }
                                                        ?>
                                                        <span class="badge <?php echo $type_badge; ?>" style="color: white; padding: 0.2rem 0.5rem; border-radius: 4px;">
                                                            <?php echo ucfirst($history['posting_type'] ?? ''); ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo $history['created_at'] ?? ''; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div style="text-align: center; padding: 2rem; color: #999; font-size: 0.9rem;"> <!-- Reduced font-size -->
                                    <i class="fas fa-history fa-2x" style="margin-bottom: 1rem;"></i>
                                    <p>No posting history available for this personnel.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 2rem;">
                            <a href="search.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back to All Records
                            </a>
                            
                            <?php if (isset($search_results['personnel']['serviceNo'])): ?>
                            <a href="edit_posting.php?serviceNo=<?php echo urlencode($search_results['personnel']['serviceNo']); ?>" class="btn btn-warning">
                                <i class="fas fa-map-marker-alt"></i> Update Posting
                            </a>
                            <!-- NEW PRINT BUTTON ADDED HERE -->
                            <button onclick="printPersonnelRecord()" class="btn btn-print">
                                <i class="fas fa-print"></i> Print Record
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Printable Area (hidden by default) -->
                <div id="printableContent" style="display: none;">
                    <div class="printable-area">
                        <div style="text-align: center; margin-bottom: 30px; border-bottom: 3px solid #000; padding-bottom: 20px;">
                            <h1 style="margin: 0; color: #000;">Nigeria Immigration Service</h1>
                            <h2 style="margin: 10px 0; color: #000;">Personnel Posting Management System</h2>
                            <h3 style="margin: 0; color: #666;">Personnel Record</h3>
                            <p style="margin: 5px 0; font-size: 14px;">Printed on: <?php echo date('F j, Y h:i A'); ?></p>
                        </div>
                        
                        <div style="margin-bottom: 30px;">
                            <h4 style="color: #000; border-bottom: 2px solid #000; padding-bottom: 5px; margin-bottom: 15px;">Personal Information</h4>
                            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                                <tr>
                                    <td style="width: 40%; padding: 8px; border: 1px solid #000; font-weight: bold;">Service Number</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['serviceNo'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">Surname</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['surname'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">First Name</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['firstName'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">Middle Name</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['middleName'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">Full Name</td>
                                    <td style="padding: 8px; border: 1px solid #000;">
                                        <strong>
                                            <?php 
                                            echo htmlspecialchars($search_results['personnel']['surname'] ?? '') . ' ' . 
                                                 htmlspecialchars($search_results['personnel']['firstName'] ?? '') . ' ' . 
                                                 htmlspecialchars($search_results['personnel']['middleName'] ?? '');
                                            ?>
                                        </strong>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="margin-bottom: 30px;">
                            <h4 style="color: #000; border-bottom: 2px solid #000; padding-bottom: 5px; margin-bottom: 15px;">Employment Information</h4>
                            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                                <tr>
                                    <td style="width: 40%; padding: 8px; border: 1px solid #000; font-weight: bold;">Current Rank</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['currentRank'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">Date of First Appointment</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['dofa'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">Date of Present Appointment</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['dopa'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">Employment Status</td>
                                    <td style="padding: 8px; border: 1px solid #000;"><?php echo htmlspecialchars($search_results['personnel']['empStatus'] ?? 'N/A'); ?></td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="margin-bottom: 30px;">
                            <h4 style="color: #000; border-bottom: 2px solid #000; padding-bottom: 5px; margin-bottom: 15px;">Posting Information</h4>
                            <div style="background: #f5f5f5; padding: 15px; border: 2px solid #000; margin-bottom: 20px;">
                                <h5 style="margin: 0 0 10px 0; color: #000;">Current Posting Location</h5>
                                <p style="margin: 0; font-size: 16px; font-weight: bold;">
                                    <?php echo $current_posting_data ? htmlspecialchars($current_posting_data['posting_location'] ?? '') : htmlspecialchars($search_results['personnel']['presentPosting'] ?? 'N/A'); ?>
                                </p>
                                <?php if ($current_posting_data): ?>
                                <p style="margin: 5px 0 0 0; font-size: 12px;">
                                    Last updated: <?php echo $current_posting_data['updated_at'] ?? ''; ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            
                            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                                <tr>
                                    <td style="width: 40%; padding: 8px; border: 1px solid #000; font-weight: bold;">Original Posting (Employment Record)</td>
                                    <td style="padding: 8px; border: 1px solid #000;">
                                        <?php echo htmlspecialchars($search_results['personnel']['presentPosting'] ?? 'N/A'); ?>
                                        <?php if ($current_posting_data && ($search_results['personnel']['presentPosting'] ?? '') !== ($current_posting_data['posting_location'] ?? '')): ?>
                                            <span style="margin-left: 10px; font-size: 12px; background: #fff3cd; padding: 2px 8px; border-radius: 4px;">
                                                (Updated from original)
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <?php if (!empty($posting_history)): ?>
                        <div class="page-break">
                            <h4 style="color: #000; border-bottom: 2px solid #000; padding-bottom: 5px; margin-bottom: 15px;">Posting History</h4>
                            <table style="width: 100%; border-collapse: collapse; margin-top: 10px; border: 1px solid #000;">
                                <thead>
                                    <tr style="background: #f0f0f0;">
                                        <th style="padding: 10px; border: 1px solid #000; text-align: left;">Posting Location</th>
                                        <th style="padding: 10px; border: 1px solid #000; text-align: left;">Posting Date</th>
                                        <th style="padding: 10px; border: 1px solid #000; text-align: left;">Type</th>
                                        <th style="padding: 10px; border: 1px solid #000; text-align: left;">Recorded On</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($posting_history as $history): ?>
                                        <tr>
                                            <td style="padding: 8px; border: 1px solid #000;">
                                                <?php echo htmlspecialchars($history['posting_location'] ?? ''); ?>
                                                <?php if ($current_posting_data && ($history['posting_location'] ?? '') === ($current_posting_data['posting_location'] ?? '')): ?>
                                                    <span style="font-size: 11px; background: #d4edda; padding: 2px 6px; border-radius: 3px; margin-left: 5px;">
                                                        Current
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td style="padding: 8px; border: 1px solid #000;"><?php echo $history['posting_date'] ?? ''; ?></td>
                                            <td style="padding: 8px; border: 1px solid #000;"><?php echo ucfirst($history['posting_type'] ?? ''); ?></td>
                                            <td style="padding: 8px; border: 1px solid #000;"><?php echo $history['created_at'] ?? ''; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                        
                        <div style="margin-top: 50px; padding-top: 20px; border-top: 2px dashed #000; text-align: center;">
                            <p style="font-size: 12px; color: #666;">
                                This is an official document from the Nigeria Immigration Service Personnel Posting Management System.
                            </p>
                            <p style="font-size: 11px; color: #999;">
                                Document ID: NIS-PPMS-<?php echo date('Ymd-His'); ?> | Service No: <?php echo htmlspecialchars($search_results['personnel']['serviceNo'] ?? ''); ?>
                            </p>
                        </div>
                    </div>
                </div>
                
            <?php elseif (!$search_performed && !empty($all_personnel)): ?>
                <!-- All Records View with Pagination -->
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                        <div>
                            <i class="fas fa-list"></i> All Personnel Records 
                            <span class="badge bg-secondary">Page <?php echo $page; ?> of <?php echo $totalPages; ?></span>
                        </div>
                    </div>
                    
                    <!-- Page info -->
                    <!--<div class="page-info">-->
                    <!--    Showing <?php echo count($all_personnel); ?> records of <?php echo $totalRecords; ?> total-->
                    <!--</div>-->
                    
                    <div class="card-body" style="padding: 0;">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Service No</th>
                                        <th>Surname</th>
                                        <th>First Name</th>
                                        <th>Current Rank</th>
                                        <th>Current Location</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_personnel as $person): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($person['serviceNo'] ?? ''); ?></strong>
                                            </td>
                                            <td><?php echo htmlspecialchars($person['surname'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($person['firstName'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($person['currentRank'] ?? 'N/A'); ?></td>
                                            <td>
                                                <?php 
                                                $current_loc = $person['current_location'] ?? $person['presentPosting'] ?? 'N/A';
                                                echo htmlspecialchars($current_loc); 
                                                if ($current_loc !== ($person['presentPosting'] ?? '')): ?>
                                                    <span class="location-badge location-mismatch" style="margin-left: 0.5rem; font-size: 0.7rem;">
                                                        <i class="fas fa-sync-alt"></i> Updated
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php 
                                                $status = $person['empStatus'] ?? 'N/A';
                                                $status_class = '';
                                                if (strtolower($status) === 'active') {
                                                    $status_class = 'status-active';
                                                } elseif (strtolower($status) === 'inactive') {
                                                    $status_class = 'status-inactive';
                                                } elseif (strtolower($status) === 'pending') {
                                                    $status_class = 'status-pending';
                                                }
                                                ?>
                                                <span class="<?php echo $status_class; ?>">
                                                    <?php echo htmlspecialchars($status); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="search.php?serviceNo=<?php echo urlencode($person['serviceNo'] ?? ''); ?>" 
                                                       class="btn btn-success" title="View Details">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="edit_posting.php?serviceNo=<?php echo urlencode($person['serviceNo'] ?? ''); ?>" 
                                                       class="btn btn-warning" title="Update Posting">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="search.php?page=1" class="page-link">
                                    <i class="fas fa-angle-double-left"></i> First
                                </a>
                                <a href="search.php?page=<?php echo $page - 1; ?>" class="page-link">
                                    <i class="fas fa-angle-left"></i> Previous
                                </a>
                            <?php endif; ?>
                            
                            <?php 
                            // Show page numbers
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++):
                            ?>
                                <a href="search.php?page=<?php echo $i; ?>" 
                                   class="page-link <?php echo $i == $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <a href="search.php?page=<?php echo $page + 1; ?>" class="page-link">
                                    Next <i class="fas fa-angle-right"></i>
                                </a>
                                <a href="search.php?page=<?php echo $totalPages; ?>" class="page-link">
                                    Last <i class="fas fa-angle-double-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        
                        <!-- ADDED BACK TO DASHBOARD BUTTON AT BOTTOM OF TABLE -->
                        <!--<div style="padding: 1rem 1.5rem; display: flex; justify-content: flex-end;">-->
                        <!--    <a href="dashboard.php" class="btn btn-light">-->
                        <!--        <i class="fas fa-home"></i> Back to Dashboard-->
                        <!--    </a>-->
                        <!--</div>-->
                    </div>
                </div>
                
            <?php elseif (!$search_performed && empty($all_personnel)): ?>
                <!-- No Records Found -->
                <div class="card">
                    <div class="card-body empty-state">
                        <i class="fas fa-users"></i>
                        <h3 style="font-size: 1.2rem;">No Personnel Records Found</h3> <!-- Reduced font-size -->
                        <p style="font-size: 0.9rem;">There are no personnel records in the database yet.</p> <!-- Reduced font-size -->
                        <div style="display: flex; gap: 0.5rem; justify-content: center; margin-top: 1.5rem; flex-wrap: wrap;">
                            <a href="dashboard.php" class="btn btn-light">
                                <i class="fas fa-home"></i> Back to Dashboard
                            </a>
                            <a href="add_personnel.php" class="btn btn-success">
                                <i class="fas fa-user-plus"></i> Add Personal Record
                            </a>
                            <a href="add_employment.php" class="btn btn-info">
                                <i class="fas fa-briefcase"></i> Add Employment Record
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Bootstrap JS (optional, for some components) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Add some interactivity to the posting history
    document.addEventListener('DOMContentLoaded', function() {
        // Add click event to history rows to show more details
        const historyRows = document.querySelectorAll('.history-table tbody tr');
        historyRows.forEach(row => {
            row.addEventListener('click', function() {
                this.classList.toggle('selected');
            });
        });
        
        // Make table rows clickable for the main table
        const mainTableRows = document.querySelectorAll('.table tbody tr');
        mainTableRows.forEach(row => {
            const link = row.querySelector('.btn-success');
            if (link) {
                row.style.cursor = 'pointer';
                row.addEventListener('click', function(e) {
                    if (!e.target.closest('.btn') && !e.target.closest('.btn-group')) {
                        window.location.href = link.href;
                    }
                });
            }
        });
        
        // Add loading indicator for search form submission
        const searchForm = document.querySelector('.search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', function() {
                // Show loading indicator if search is taking time
                setTimeout(function() {
                    const searchBtn = document.querySelector('.search-btn');
                    if (searchBtn && !searchBtn.querySelector('.fa-spinner')) {
                        searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching...';
                        searchBtn.disabled = true;
                    }
                }, 1000);
            });
        }
    });
    
    // Print function for personnel records
    function printPersonnelRecord() {
        // Get the printable content
        const printableContent = document.getElementById('printableContent').innerHTML;
        
        // Create a new window for printing
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        
        // Write the printable content to the new window
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Print Personnel Record - NIS PPMS</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 20px;
                        color: #000;
                    }
                    @media print {
                        @page {
                            size: A4;
                            margin: 0.5in;
                        }
                        body {
                            margin: 0;
                            font-size: 12pt;
                        }
                        .page-break {
                            page-break-before: always;
                        }
                        table {
                            page-break-inside: avoid;
                        }
                    }
                    h1, h2, h3, h4 {
                        color: #000;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin: 10px 0;
                    }
                    th, td {
                        padding: 8px;
                        border: 1px solid #000;
                        text-align: left;
                    }
                    th {
                        background-color: #f0f0f0;
                        font-weight: bold;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 30px;
                        border-bottom: 3px solid #000;
                        padding-bottom: 20px;
                    }
                    .footer {
                        margin-top: 50px;
                        padding-top: 20px;
                        border-top: 2px dashed #000;
                        text-align: center;
                        font-size: 11px;
                        color: #666;
                    }
                    .current-posting-box {
                        background: #f5f5f5;
                        padding: 15px;
                        border: 2px solid #000;
                        margin: 15px 0;
                    }
                </style>
            </head>
            <body>
                ${printableContent}
                <script>
                    window.onload = function() {
                        window.print();
                        setTimeout(function() {
                            window.close();
                        }, 500);
                    };
                <\/script>
            </body>
            </html>
        `);
        
        printWindow.document.close();
    }
    
    // Alternative print function (direct printing without new window)
    function printRecordDirect() {
        window.print();
    }
    </script>
</body>
</html>