<?php
// Enable error reporting at the very top
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
session_start();

// Include files with error handling
try {
    require_once 'includes/config.php';
    require_once 'includes/auth.php';
    require_once 'includes/permissions.php';
} catch (Exception $e) {
    die("Error loading required files: " . $e->getMessage());
}

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Initialize variables with default values
$user = [];
$totalPersonnel = 0;
$totalUsers = 0;
$avgAge = 0;
$activePersonnel = 0;
$recentActivities = [];
$error = null;

// Initialize statistics arrays
$commandStats = [];
$zoneStats = [];
$passportOfficeStats = [];
$borderStats = [];
$headquartersStats = [];
$topCommands = [];
$formationStats = [];
$monthlyPersonnelData = [];
$rankDistributionData = [];
$zonePersonnelData = [];
$genderStats = [];
$regionStats = [];
$ageDistributionData = [];
$serviceYearsData = [];
$departmentStats = [];
$locationStats = []; // For location distribution (presentPosting)

try {
    // Get user information
    $stmt = $pdo->prepare("
        SELECT u.*, r.name as role_name
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception("User not found");
    }

    // DEBUG: Check what tables and columns exist
    $debugMode = false; // Set to true to see database structure
    if ($debugMode) {
        echo "<pre style='background: #f8f9fa; padding: 20px; border: 1px solid #ddd; margin: 20px;'>";
        echo "DEBUG MODE - Database Structure\n";
        echo "================================\n";
        
        // List all tables
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        echo "Available tables:\n";
        foreach ($tables as $table) {
            echo "- $table\n";
        }
        
        // Check tbl_emppersonal columns
        if (in_array('tbl_emppersonal', $tables)) {
            echo "\nColumns in tbl_emppersonal:\n";
            $columns = $pdo->query("SHOW COLUMNS FROM tbl_emppersonal")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($columns as $col) {
                echo "- {$col['Field']} ({$col['Type']})\n";
            }
        }
        
        // Check tbl_employment columns
        if (in_array('tbl_employment', $tables)) {
            echo "\nColumns in tbl_employment:\n";
            $columns = $pdo->query("SHOW COLUMNS FROM tbl_employment")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($columns as $col) {
                echo "- {$col['Field']} ({$col['Type']})\n";
            }
        }
        
        echo "</pre>";
    }

    // Get KPI statistics - REAL DATA
    try {
        // Total Personnel (from tbl_emppersonal)
        $totalPersonnel = $pdo->query("SELECT COUNT(*) as count FROM tbl_emppersonal")->fetch()['count'];
    } catch (Exception $e) {
        error_log("Total personnel query failed: " . $e->getMessage());
        $totalPersonnel = 0;
    }

    try {
        // System Users (from users table)
        $totalUsers = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
    } catch (Exception $e) {
        error_log("Total users query failed: " . $e->getMessage());
        $totalUsers = 0;
    }

    try {
        // Average Age - Check if dateOfBirth column exists in tbl_emppersonal
        $avgAgeResult = $pdo->query("
            SELECT AVG(YEAR(CURDATE()) - YEAR(dateOfBirth)) as avg_age 
            FROM tbl_emppersonal 
            WHERE dateOfBirth IS NOT NULL 
            AND dateOfBirth != '0000-00-00'
            AND dateOfBirth != ''
        ")->fetch();
        $avgAge = $avgAgeResult['avg_age'] ? round($avgAgeResult['avg_age'], 1) : 0;
    } catch (Exception $e) {
        error_log("Average age query failed: " . $e->getMessage());
        $avgAge = 0;
    }

    try {
        // Active Personnel - Check if status field exists
        $checkStatus = $pdo->query("SHOW COLUMNS FROM tbl_emppersonal LIKE 'status'")->fetch();
        if ($checkStatus) {
            $activePersonnel = $pdo->query("
                SELECT COUNT(*) as count 
                FROM tbl_emppersonal 
                WHERE status = 'Active' OR status = 'active'
            ")->fetch()['count'];
        } else {
            $activePersonnel = $totalPersonnel;
        }
    } catch (Exception $e) {
        error_log("Active personnel query failed: " . $e->getMessage());
        $activePersonnel = $totalPersonnel;
    }

    // Get recent activities
    try {
        $recentActivities = $pdo->query("
            SELECT al.*, u.username 
            FROM activity_logs al
            JOIN users u ON al.user_id = u.id
            ORDER BY al.created_at DESC
            LIMIT 5
        ")->fetchAll();
    } catch (Exception $e) {
        error_log("Recent activities query failed: " . $e->getMessage());
        $recentActivities = [];
    }

    // Get analytics data for charts - REAL DATA
    try {
        // Gender distribution
        $genderStats = $pdo->query("
            SELECT 
                CASE 
                    WHEN gender IS NULL OR TRIM(gender) = '' THEN 'Not Specified'
                    ELSE gender
                END as gender,
                COUNT(*) as count 
            FROM tbl_emppersonal 
            GROUP BY CASE 
                WHEN gender IS NULL OR TRIM(gender) = '' THEN 'Not Specified'
                ELSE gender
            END
            ORDER BY count DESC
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Gender stats query failed: " . $e->getMessage());
        $genderStats = [];
    }
    
    try {
        // Rank distribution - Check both tables and use correct column
        // First check if currentRank exists in tbl_emppersonal
        $checkRankColumn = $pdo->query("SHOW COLUMNS FROM tbl_emppersonal LIKE 'currentRank'")->fetch();
        
        if ($checkRankColumn) {
            // Use currentRank from tbl_emppersonal
            $rankDistributionData = $pdo->query("
                SELECT 
                    COALESCE(NULLIF(TRIM(currentRank), ''), 'Not Specified') as rank_name,
                    COUNT(*) as count
                FROM tbl_emppersonal 
                WHERE currentRank IS NOT NULL
                GROUP BY COALESCE(NULLIF(TRIM(currentRank), ''), 'Not Specified')
                ORDER BY count DESC
                LIMIT 15
            ")->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // Check tbl_employment table
            $checkEmploymentTable = $pdo->query("SHOW TABLES LIKE 'tbl_employment'")->fetch();
            if ($checkEmploymentTable) {
                $rankDistributionData = $pdo->query("
                    SELECT 
                        COALESCE(NULLIF(TRIM(currentRank), ''), 'Not Specified') as rank_name,
                        COUNT(*) as count
                    FROM tbl_employment 
                    WHERE currentRank IS NOT NULL
                    GROUP BY COALESCE(NULLIF(TRIM(currentRank), ''), 'Not Specified')
                    ORDER BY count DESC
                    LIMIT 15
                ")->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $rankDistributionData = [['rank_name' => 'Not Specified', 'count' => $totalPersonnel]];
            }
        }
    } catch (Exception $e) {
        error_log("Rank distribution query failed: " . $e->getMessage());
        $rankDistributionData = [['rank_name' => 'Not Specified', 'count' => $totalPersonnel]];
    }

    try {
        // Command distribution - Check if command column exists
        $checkCommandColumn = $pdo->query("SHOW COLUMNS FROM tbl_emppersonal LIKE 'command'")->fetch();
        
        if ($checkCommandColumn) {
            $commandStats = $pdo->query("
                SELECT 
                    CASE 
                        WHEN command IS NULL OR TRIM(command) = '' THEN 'Not Specified'
                        ELSE command
                    END as command_name,
                    COUNT(*) as count 
                FROM tbl_emppersonal 
                WHERE command IS NOT NULL
                GROUP BY CASE 
                    WHEN command IS NULL OR TRIM(command) = '' THEN 'Not Specified'
                    ELSE command
                END
                ORDER BY count DESC
                LIMIT 10
            ")->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $commandStats = [['command_name' => 'Not Specified', 'count' => $totalPersonnel]];
        }
    } catch (Exception $e) {
        error_log("Command stats query failed: " . $e->getMessage());
        $commandStats = [['command_name' => 'Not Specified', 'count' => $totalPersonnel]];
    }

    try {
        // Department distribution - Check if department column exists
        $checkDeptColumn = $pdo->query("SHOW COLUMNS FROM tbl_emppersonal LIKE 'department'")->fetch();
        
        if ($checkDeptColumn) {
            $departmentStats = $pdo->query("
                SELECT 
                    CASE 
                        WHEN department IS NULL OR TRIM(department) = '' THEN 'Not Specified'
                        ELSE department
                    END as department_name,
                    COUNT(*) as count 
                FROM tbl_emppersonal 
                WHERE department IS NOT NULL
                GROUP BY CASE 
                    WHEN department IS NULL OR TRIM(department) = '' THEN 'Not Specified'
                    ELSE department
                END
                ORDER BY count DESC
                LIMIT 8
            ")->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $departmentStats = [['department_name' => 'Not Specified', 'count' => $totalPersonnel]];
        }
    } catch (Exception $e) {
        error_log("Department stats query failed: " . $e->getMessage());
        $departmentStats = [['department_name' => 'Not Specified', 'count' => $totalPersonnel]];
    }

    try {
        // Regional distribution - Check if stateOrigin column exists
        $checkRegionColumn = $pdo->query("SHOW COLUMNS FROM tbl_emppersonal LIKE 'state_of_origin'")->fetch();
        
        if ($checkRegionColumn) {
            // First check if regions table exists
            $checkRegionsTable = $pdo->query("SHOW TABLES LIKE 'regions'")->fetch();
            
            if ($checkRegionsTable) {
                $regionStats = $pdo->query("
                    SELECT 
                        COALESCE(NULLIF(TRIM(r.region_name), ''), 'Not Specified') as region_name,
                        COUNT(e.id) as count
                    FROM tbl_emppersonal e
                    LEFT JOIN regions r ON e.state_of_origin = r.region_code
                    GROUP BY COALESCE(NULLIF(TRIM(r.region_name), ''), 'Not Specified')
                    ORDER BY count DESC
                    LIMIT 10
                ")->fetchAll(PDO::FETCH_ASSOC);
            } else {
                // Use state_of_origin directly
                $regionStats = $pdo->query("
                    SELECT 
                        COALESCE(NULLIF(TRIM(state_of_origin), ''), 'Not Specified') as region_name,
                        COUNT(*) as count
                    FROM tbl_emppersonal
                    GROUP BY COALESCE(NULLIF(TRIM(state_of_origin), ''), 'Not Specified')
                    ORDER BY count DESC
                    LIMIT 10
                ")->fetchAll(PDO::FETCH_ASSOC);
            }
        } else {
            $regionStats = [['region_name' => 'Not Specified', 'count' => $totalPersonnel]];
        }
    } catch (Exception $e) {
        error_log("Region stats query failed: " . $e->getMessage());
        $regionStats = [['region_name' => 'Not Specified', 'count' => $totalPersonnel]];
    }

    try {
        // Age distribution
        $ageDistributionData = $pdo->query("
            SELECT 
                CASE 
                    WHEN dateOfBirth IS NULL OR dateOfBirth = '0000-00-00' OR dateOfBirth = '' THEN 'Not Specified'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) < 20 THEN 'Under 20'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) BETWEEN 20 AND 29 THEN '20-29'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) BETWEEN 30 AND 39 THEN '30-39'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) BETWEEN 40 AND 49 THEN '40-49'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) >= 50 THEN '50+'
                    ELSE 'Not Specified'
                END as age_group,
                COUNT(*) as count
            FROM tbl_emppersonal 
            GROUP BY 
                CASE 
                    WHEN dateOfBirth IS NULL OR dateOfBirth = '0000-00-00' OR dateOfBirth = '' THEN 'Not Specified'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) < 20 THEN 'Under 20'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) BETWEEN 20 AND 29 THEN '20-29'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) BETWEEN 30 AND 39 THEN '30-39'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) BETWEEN 40 AND 49 THEN '40-49'
                    WHEN YEAR(CURDATE()) - YEAR(dateOfBirth) >= 50 THEN '50+'
                    ELSE 'Not Specified'
                END
            ORDER BY 
                CASE 
                    WHEN age_group = 'Under 20' THEN 1
                    WHEN age_group = '20-29' THEN 2
                    WHEN age_group = '30-39' THEN 3
                    WHEN age_group = '40-49' THEN 4
                    WHEN age_group = '50+' THEN 5
                    ELSE 6
                END
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Age distribution query failed: " . $e->getMessage());
        $ageDistributionData = [['age_group' => 'Not Specified', 'count' => $totalPersonnel]];
    }

    try {
        // Service years distribution
        $serviceYearsData = $pdo->query("
            SELECT 
                CASE 
                    WHEN yearOfEngagement IS NULL OR yearOfEngagement = 0 OR yearOfEngagement = '' THEN 'Not Specified'
                    WHEN YEAR(CURDATE()) - yearOfEngagement < 5 THEN '0-4 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement BETWEEN 5 AND 9 THEN '5-9 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement BETWEEN 10 AND 14 THEN '10-14 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement BETWEEN 15 AND 19 THEN '15-19 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement >= 20 THEN '20+ years'
                    ELSE 'Not Specified'
                END as service_years,
                COUNT(*) as count
            FROM tbl_emppersonal 
            GROUP BY 
                CASE 
                    WHEN yearOfEngagement IS NULL OR yearOfEngagement = 0 OR yearOfEngagement = '' THEN 'Not Specified'
                    WHEN YEAR(CURDATE()) - yearOfEngagement < 5 THEN '0-4 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement BETWEEN 5 AND 9 THEN '5-9 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement BETWEEN 10 AND 14 THEN '10-14 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement BETWEEN 15 AND 19 THEN '15-19 years'
                    WHEN YEAR(CURDATE()) - yearOfEngagement >= 20 THEN '20+ years'
                    ELSE 'Not Specified'
                END
            ORDER BY 
                CASE 
                    WHEN service_years = '0-4 years' THEN 1
                    WHEN service_years = '5-9 years' THEN 2
                    WHEN service_years = '10-14 years' THEN 3
                    WHEN service_years = '15-19 years' THEN 4
                    WHEN service_years = '20+ years' THEN 5
                    ELSE 6
                END
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Service years query failed: " . $e->getMessage());
        $serviceYearsData = [['service_years' => 'Not Specified', 'count' => $totalPersonnel]];
    }

    // UPDATED: Location Distribution from tbl_employment table, presentPosting column
    try {
        // Check if tbl_employment table exists
        $checkEmploymentTable = $pdo->query("SHOW TABLES LIKE 'tbl_employment'")->fetch();
        
        if ($checkEmploymentTable) {
            // Check if presentPosting column exists in tbl_employment table
            $checkPresentPostingColumn = $pdo->query("SHOW COLUMNS FROM tbl_employment LIKE 'presentPosting'")->fetch();
            
            if ($checkPresentPostingColumn) {
                // Get location distribution from tbl_employment table, presentPosting column
                $locationStats = $pdo->query("
                    SELECT 
                        COALESCE(NULLIF(TRIM(presentPosting), ''), 'Not Specified') as location_name,
                        COUNT(*) as count
                    FROM tbl_employment
                    WHERE presentPosting IS NOT NULL
                    GROUP BY COALESCE(NULLIF(TRIM(presentPosting), ''), 'Not Specified')
                    ORDER BY count DESC
                    LIMIT 10
                ")->fetchAll(PDO::FETCH_ASSOC);
            } else {
                // If no presentPosting column, check for other location-related columns
                $checkLocationColumns = $pdo->query("SHOW COLUMNS FROM tbl_employment")->fetchAll(PDO::FETCH_COLUMN);
                $possibleLocationCols = ['location', 'posting', 'station', 'duty_station'];
                $locationColumn = null;
                
                foreach ($possibleLocationCols as $col) {
                    if (in_array($col, $checkLocationColumns)) {
                        $locationColumn = $col;
                        break;
                    }
                }
                
                if ($locationColumn) {
                    $locationStats = $pdo->query("
                        SELECT 
                            COALESCE(NULLIF(TRIM($locationColumn), ''), 'Not Specified') as location_name,
                            COUNT(*) as count
                        FROM tbl_employment
                        WHERE $locationColumn IS NOT NULL
                        GROUP BY COALESCE(NULLIF(TRIM($locationColumn), ''), 'Not Specified')
                        ORDER BY count DESC
                        LIMIT 10
                    ")->fetchAll(PDO::FETCH_ASSOC);
                } else {
                    $locationStats = [['location_name' => 'Not Specified', 'count' => 0]];
                }
            }
        } else {
            $locationStats = [['location_name' => 'Not Specified', 'count' => 0]];
        }
    } catch (Exception $e) {
        error_log("Location stats query failed: " . $e->getMessage());
        $locationStats = [['location_name' => 'Not Specified', 'count' => 0]];
    }

    // Get total commands, zones, departments, and ranks counts
    try {
        $totalCommands = $pdo->query("
            SELECT COUNT(DISTINCT CASE 
                WHEN command IS NULL OR TRIM(command) = '' THEN NULL 
                ELSE command 
            END) as count 
            FROM tbl_emppersonal
        ")->fetch()['count'] ?? 0;
    } catch (Exception $e) {
        $totalCommands = 0;
    }

    try {
        $totalZones = $pdo->query("
            SELECT COUNT(DISTINCT CASE 
                WHEN zone IS NULL OR TRIM(zone) = '' THEN NULL 
                ELSE zone 
            END) as count 
            FROM tbl_emppersonal
        ")->fetch()['count'] ?? 0;
    } catch (Exception $e) {
        $totalZones = 0;
    }

} catch (Exception $e) {
    $error = "Error loading dashboard data: " . $e->getMessage();
    error_log($error);
}

// Set safe defaults
if (empty($user)) {
    $user = [
        'username' => $_SESSION['username'] ?? 'User',
        'full_name' => $_SESSION['username'] ?? 'User',
        'role_name' => 'User'
    ];
}

// Prepare data for JavaScript with proper error handling
function safeJsonEncode($data, $field1, $field2) {
    if (empty($data) || !is_array($data)) {
        return ['[]', '[]'];
    }
    
    $labels = [];
    $values = [];
    
    foreach ($data as $item) {
        if (isset($item[$field1]) && isset($item[$field2])) {
            $labels[] = $item[$field1];
            $values[] = $item[$field2];
        }
    }
    
    if (empty($labels) || empty($values)) {
        return ['[]', '[]'];
    }
    
    return [
        json_encode($labels),
        json_encode($values)
    ];
}

// Prepare all chart data
list($rankLabels, $rankValues) = safeJsonEncode($rankDistributionData, 'rank_name', 'count');
list($regionLabels, $regionValues) = safeJsonEncode($regionStats, 'region_name', 'count');
list($genderLabels, $genderValues) = safeJsonEncode($genderStats, 'gender', 'count');
list($ageLabels, $ageValues) = safeJsonEncode($ageDistributionData, 'age_group', 'count');
list($serviceYearsLabels, $serviceYearsValues) = safeJsonEncode($serviceYearsData, 'service_years', 'count');
list($commandLabels, $commandValues) = safeJsonEncode($commandStats, 'command_name', 'count');
list($departmentLabels, $departmentValues) = safeJsonEncode($departmentStats, 'department_name', 'count');
list($locationLabels, $locationValues) = safeJsonEncode($locationStats, 'location_name', 'count');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <title>NIS-PPMS-Dashboard</title>
    <!-- Add Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
    /* CSS Reset */
    * { 
        margin: 0; 
        padding: 0; 
        box-sizing: border-box; 
    }
    
    /* Body styling - RESTORED ORIGINAL BACKGROUND */
    body { 
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: 
            linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(39, 174, 96, 0.9) 100%),
            url('assets/images/tech_building.jpg') center/cover no-repeat fixed;
        min-height: 100vh;
        color: #333;
        width: 100%;
        overflow-x: hidden;
    }
    
    /* Header styling - RESPONSIVE UPDATES */
    .header-container {
        background: rgba(255, 255, 255, 0.98);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        padding: 0.8rem 1rem;
        position: sticky;
        top: 0;
        z-index: 1000;
        backdrop-filter: blur(5px);
        border-bottom: 2px solid #27ae60;
        width: 100%;
    }
    
    .header-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 1rem;
    }
    
    .logo-title-container {
        display: flex;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        min-width: 200px;
    }
    
    .header-logo {
        height: 40px;
        width: auto;
        object-fit: contain;
        max-width: 100%;
    }
    
    .system-title {
        color: #2c3e50;
        font-size: 1.2rem;
        font-weight: 800;
        margin: 0;
        word-break: break-word;
        line-height: 1.3;
    }
    
    .user-info {
        display: flex;
        align-items: center;
        gap: 0.8rem;
        flex-shrink: 0;
    }
    
    .user-profile {
        width: 35px;
        height: 35px;
        background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 1rem;
        flex-shrink: 0;
    }
    
    /* Dashboard layout - RESPONSIVE UPDATES */
    .dashboard-container {
        padding: 1rem;
        max-width: 100%;
        margin: 0 auto;
        width: 100%;
        overflow-x: hidden;
    }
    
    .content-wrapper {
        display: flex;
        gap: 1.5rem;
        flex-wrap: wrap;
        width: 100%;
    }
    
    /* Main content - RESPONSIVE UPDATES */
    .main-content {
        flex: 1;
        min-width: 0; /* Allows flex item to shrink below min-content */
        width: 100%;
        overflow-x: hidden;
    }
    
    /* KPI Cards - RESPONSIVE UPDATES */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1rem;
        margin-bottom: 1.5rem;
        width: 100%;
    }
    
    @media (max-width: 576px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
    }
    
    .stat-card {
        background: linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(39, 174, 96, 0.9) 100%);
        color: white;
        border-radius: 12px;
        padding: 1.2rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        transition: transform 0.3s ease;
        min-height: 120px;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    }
    
    .stat-card.primary {
        background: linear-gradient(135deg, #2c3e50 0%, #4a90e2 100%);
    }
    
    .stat-card.info {
        background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
    }
    
    .stat-card.warning {
        background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
    }
    
    .stat-content {
        flex: 1;
        min-width: 0;
    }
    
    .stat-content h3 {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 0.3rem;
        word-break: break-word;
    }
    
    .stat-content p {
        opacity: 0.9;
        font-size: 0.9rem;
        margin-bottom: 0.3rem;
        word-break: break-word;
    }
    
    .stat-content small {
        opacity: 0.8;
        font-size: 0.8rem;
        word-break: break-word;
    }
    
    .stat-icon {
        background: rgba(255, 255, 255, 0.2);
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
        flex-shrink: 0;
        margin-left: 1rem;
    }
    
    /* Charts section - RESPONSIVE UPDATES */
    .charts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 1rem;
        margin-bottom: 1.5rem;
        width: 100%;
    }
    
    @media (max-width: 768px) {
        .charts-grid {
            grid-template-columns: 1fr;
        }
    }
    
    .chart-container {
        position: relative;
        height: 280px;
        width: 100%;
        min-height: 250px;
    }
    
    /* Bar chart specific styling */
    .bar-chart-container {
        height: 300px;
        position: relative;
    }
    
    /* Cards - RESPONSIVE UPDATES */
    .card {
        background: rgba(255, 255, 255, 0.98);
        border-radius: 12px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        margin-bottom: 1rem;
        overflow: hidden;
        border: 1px solid rgba(39, 174, 96, 0.1);
        transition: transform 0.3s ease;
        width: 100%;
        max-width: 100%;
        overflow-x: hidden;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    
    .card-header {
        background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
        color: white;
        padding: 0.8rem 1.2rem;
        font-weight: 600;
        font-size: 1rem;
        border: none;
    }
    
    .card-body {
        padding: 1.2rem;
    }
    
    /* Chart controls - RESPONSIVE UPDATES */
    .chart-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
        flex-wrap: wrap;
        gap: 0.5rem;
    }
    
    .chart-title {
        font-size: 0.95rem;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
        word-break: break-word;
    }
    
    .chart-actions {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
    }
    
    .chart-action-btn {
        background: none;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        padding: 0.3rem 0.6rem;
        cursor: pointer;
        font-size: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.3rem;
        transition: all 0.2s ease;
        white-space: nowrap;
    }
    
    .chart-action-btn:hover {
        background: #f8f9fa;
    }
    
    /* Chart type selector */
    .chart-type-selector {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1rem;
        flex-wrap: wrap;
    }
    
    .chart-type-btn {
        padding: 0.4rem 0.8rem;
        background: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        cursor: pointer;
        font-size: 0.85rem;
        transition: all 0.2s ease;
        white-space: nowrap;
    }
    
    .chart-type-btn:hover {
        background: #e9ecef;
    }
    
    .chart-type-btn.active {
        background: #27ae60;
        color: white;
        border-color: #27ae60;
    }
    
    /* NIS Structure Stats - RESPONSIVE UPDATES */
    .nis-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
        gap: 0.8rem;
        margin: 1rem 0;
    }
    
    @media (max-width: 480px) {
        .nis-stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    .nis-stat-item {
        text-align: center;
        padding: 0.8rem 0.5rem;
        border-radius: 8px;
        background: rgba(44, 62, 80, 0.1);
        transition: all 0.3s ease;
    }
    
    .nis-stat-item:hover {
        background: rgba(44, 62, 80, 0.2);
        transform: translateY(-2px);
    }
    
    .nis-stat-value {
        font-size: 1.3rem;
        font-weight: bold;
        color: #2c3e50;
        display: block;
        word-break: break-word;
    }
    
    .nis-stat-label {
        font-size: 0.75rem;
        color: #666;
        margin-top: 0.3rem;
        word-break: break-word;
    }
    
    /* Data table for chart - RESPONSIVE UPDATES */
    .data-table-container {
        max-height: 200px;
        overflow-y: auto;
        overflow-x: auto;
        margin-top: 1rem;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        width: 100%;
    }
    
    .data-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.8rem;
        min-width: 300px;
    }
    
    .data-table th {
        background: #f8f9fa;
        padding: 0.5rem;
        text-align: left;
        font-weight: 600;
        color: #495057;
        border-bottom: 2px solid #dee2e6;
        position: sticky;
        top: 0;
        white-space: nowrap;
    }
    
    .data-table td {
        padding: 0.5rem;
        border-bottom: 1px solid #dee2e6;
        word-break: break-word;
    }
    
    .data-table tr:hover {
        background-color: rgba(39, 174, 96, 0.05);
    }
    
    /* Activity list */
    .activity-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .activity-item {
        padding: 0.8rem;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background-color 0.2s ease;
        flex-wrap: wrap;
    }
    
    .activity-item:hover {
        background-color: rgba(39, 174, 96, 0.05);
    }
    
    .activity-item:last-child {
        border-bottom: none;
    }
    
    .activity-content {
        flex: 1;
        min-width: 0;
    }
    
    .activity-content h6 {
        color: #2c3e50;
        margin-bottom: 0.3rem;
        font-size: 0.9rem;
        word-break: break-word;
    }
    
    .activity-time {
        color: #666;
        font-size: 0.8rem;
        flex-shrink: 0;
    }
    
    /* Realtime update indicator - RESPONSIVE UPDATES */
    .realtime-indicator {
        position: fixed;
        bottom: 10px;
        right: 10px;
        background: rgba(39, 174, 96, 0.9);
        color: white;
        padding: 0.4rem 0.8rem;
        border-radius: 20px;
        font-size: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        z-index: 1000;
        box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        animation: pulse 2s infinite;
        max-width: calc(100% - 20px);
    }
    
    @keyframes pulse {
        0% { box-shadow: 0 0 0 0 rgba(39, 174, 96, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(39, 174, 96, 0); }
        100% { box-shadow: 0 0 0 0 rgba(39, 174, 96, 0); }
    }
    
    /* Loading spinner */
    .loading-spinner {
        display: none;
        text-align: center;
        padding: 20px;
    }
    
    .spinner-border {
        width: 3rem;
        height: 3rem;
    }
    
    /* Small charts grid - RESPONSIVE UPDATES */
    .small-charts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1rem;
        margin-bottom: 1.5rem;
        width: 100%;
    }
    
    @media (max-width: 768px) {
        .small-charts-grid {
            grid-template-columns: 1fr;
        }
    }
    
    /* Quick Search Form - RESPONSIVE UPDATES */
    .stat-card.info form {
        width: 100%;
    }
    
    .stat-card.info .stat-content {
        width: 100%;
    }
    
    .stat-card.info form div {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
    }
    
    .stat-card.info input[type="text"] {
        flex: 1;
        min-width: 150px;
        padding: 0.5rem;
        border: 1px solid rgba(255,255,255,0.3);
        border-radius: 4px;
        background: white;
        color: #333;
        font-size: 0.9rem;
    }
    
    .stat-card.info button[type="submit"] {
        background: white;
        color: #27ae60;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        cursor: pointer;
        white-space: nowrap;
    }
    
    /* Alert Container */
    #alertContainer {
        margin-bottom: 1rem;
    }
    
    /* Responsive Design Improvements */
    @media (max-width: 1200px) {
        .charts-grid {
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        }
        .small-charts-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    @media (max-width: 992px) {
        .content-wrapper {
            flex-direction: column;
        }
        
        .dashboard-container {
            padding: 0.8rem;
        }
        
        .stat-content h3 {
            font-size: 1.6rem;
        }
        
        .chart-container {
            height: 250px;
        }
        
        .bar-chart-container {
            height: 270px;
        }
    }
    
    @media (max-width: 768px) {
        .header-container {
            padding: 0.6rem 0.8rem;
        }
        
        .header-content {
            justify-content: center;
            text-align: center;
        }
        
        .logo-title-container {
            justify-content: center;
            text-align: center;
            width: 100%;
        }
        
        .user-info {
            justify-content: center;
            width: 100%;
            margin-top: 0.5rem;
        }
        
        .system-title {
            font-size: 1rem;
        }
        
        .charts-grid, .small-charts-grid {
            gap: 0.8rem;
        }
        
        .card-header {
            padding: 0.7rem 1rem;
            font-size: 0.95rem;
        }
        
        .card-body {
            padding: 1rem;
        }
        
        .stat-icon {
            width: 45px;
            height: 45px;
            font-size: 1.2rem;
        }
    }
    
    @media (max-width: 576px) {
        .header-content {
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .logo-title-container {
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .user-info {
            flex-direction: column;
            text-align: center;
        }
        
        .dashboard-container {
            padding: 0.5rem;
        }
        
        .stat-card {
            flex-direction: column;
            text-align: center;
            padding: 1rem;
        }
        
        .stat-icon {
            margin-left: 0;
            margin-top: 0.5rem;
            width: 40px;
            height: 40px;
            font-size: 1.1rem;
        }
        
        .stat-content h3 {
            font-size: 1.4rem;
        }
        
        .chart-container {
            height: 230px;
        }
        
        .bar-chart-container {
            height: 250px;
        }
        
        .chart-controls {
            flex-direction: column;
            align-items: flex-start;
        }
        
        .chart-actions {
            width: 100%;
            justify-content: flex-start;
        }
        
        .nis-stats-grid {
            grid-template-columns: repeat(3, 1fr);
        }
        
        .realtime-indicator {
            bottom: 5px;
            right: 5px;
            left: 5px;
            max-width: calc(100% - 10px);
            justify-content: center;
        }
    }
    
    @media (max-width: 480px) {
        .stat-content h3 {
            font-size: 1.3rem;
        }
        
        .chart-container {
            height: 220px;
        }
        
        .bar-chart-container {
            height: 240px;
        }
        
        .nis-stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .chart-type-selector {
            justify-content: center;
        }
        
        .chart-actions {
            justify-content: center;
        }
        
        .data-table {
            font-size: 0.75rem;
        }
    }
    
    @media (max-width: 360px) {
        .stats-grid {
            gap: 0.8rem;
        }
        
        .stat-card {
            padding: 0.8rem;
            min-height: 100px;
        }
        
        .stat-content h3 {
            font-size: 1.2rem;
        }
        
        .chart-container {
            height: 200px;
        }
        
        .bar-chart-container {
            height: 220px;
        }
        
        .nis-stats-grid {
            grid-template-columns: 1fr;
        }
        
        .stat-card.info input[type="text"] {
            min-width: 120px;
        }
    }
    
    /* Animation for counter numbers */
    .counter {
        font-weight: bold;
    }
    
    /* Improve touch targets on mobile */
    @media (hover: none) and (pointer: coarse) {
        .chart-action-btn,
        .chart-type-btn,
        .stat-card.info button[type="submit"] {
            min-height: 44px;
            min-width: 44px;
        }
        
        .data-table th,
        .data-table td {
            padding: 0.6rem;
        }
    }
</style>
</head>
<body>
    <!-- Header - RESTORED ORIGINAL -->
    <div class="header-container">
        <div class="header-content">
            <div class="logo-title-container">
                <img src="assets/images/logo.png" alt="NIS Logo" class="header-logo">
                <h1 class="system-title">NIS Personnel Posting Management System</h1>
            </div>
            <div class="user-info">
                <div class="user-profile">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></strong><br>
                    <small><?php echo htmlspecialchars($user['role_name']); ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <!-- Alert Container -->
        <div id="alertContainer"></div>

        <?php if ($error): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert" style="background: #fff3cd; color: #856404; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid #ffeaa7;">
            <strong>Notice:</strong> <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" onclick="this.parentElement.style.display='none'" style="background: none; border: none; font-size: 1.2rem; float: right; cursor: pointer;">&times;</button>
        </div>
        <?php endif; ?>

        <div class="content-wrapper">
            <!-- Include Sidebar -->
            <?php include 'includes/sidebar.php'; ?>

            <!-- Main Content -->
            <div class="main-content">
                <!-- Loading Spinner -->
                <div id="dashboardSpinner" class="loading-spinner">
                    <div class="spinner-border text-success" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading dashboard data...</p>
                </div>

                <!-- KPI Cards Section - ALL REAL DATA NOW -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-content">
                            <h3 class="counter" id="totalPersonnel"><?php echo number_format($totalPersonnel); ?></h3>
                            <p>Total Personnel</p>
                            
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>

                    <div class="stat-card primary">
                        <div class="stat-content">
                            <h3 class="counter" id="totalUsers"><?php echo number_format($totalUsers); ?></h3>
                            <p>System Users</p>
                            
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-user-shield"></i>
                        </div>
                    </div>

                    <div class="stat-card info">
                        <div class="stat-content">
                            <h3>Quick Search</h3>
                            <form action="search.php" method="GET" style="margin-top: 0.5rem;">
                                <div style="display: flex; gap: 0.5rem;">
                                    <input type="text" placeholder="Service Number" name="serviceNo" required 
                                           style="flex: 1; padding: 0.5rem; border: 1px solid rgba(255,255,255,0.3); 
                                                  border-radius: 4px; background: white; 
                                                  color: #333; font-size: 0.9rem;">
                                    <button type="submit" style="background: white; color: #27ae60; border: none; 
                                            padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer;">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </form>
                            
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">NIS Formation Statistics</h5>
                    </div>
                    <div class="card-body">
                        <div class="nis-stats-grid">
                            <div class="nis-stat-item">
                                <span class="nis-stat-value" id="totaCommands">46</span>
                                <span class="nis-stat-label">Commands</span>
                            </div>
                            <div class="nis-stat-item">
                                <span class="nis-stat-value" id="totaZones">8</span>
                                <span class="nis-stat-label">Zones</span>
                            </div>
                            <div class="nis-stat-item">
                                <span class="nis-stat-value" id="totalPassportOffices">39</span>
                                <span class="nis-stat-label">Passport Offices</span>
                            </div>
                            <div class="nis-stat-item">
                                <span class="nis-stat-value" id="totalBorders">90</span>
                                <span class="nis-stat-label">Borders</span>
                            </div>
                            <div class="nis-stat-item">
                                <span class="nis-stat-value" id="totalHQUnits">10</span>
                                <span class="nis-stat-label">HQ Directorate</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bar Charts Section -->
                <div class="charts-grid">
                    <!-- Rank Distribution Bar Chart -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Rank Distribution (Top 15)</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-controls">
                                <div class="chart-type-selector">
                                    <button class="chart-type-btn active" onclick="changeChartType('rankDistributionChart', 'bar')">Bar</button>
                                    <button class="chart-type-btn" onclick="changeChartType('rankDistributionChart', 'horizontalBar')">Horizontal</button>
                                </div>
                                <div class="chart-actions">
                                    <button class="chart-action-btn" onclick="exportChartData('rankDistributionChart', 'rank_distribution_data')">
                                        <i class="fas fa-download"></i> Export
                                    </button>
                                    <button class="chart-action-btn" onclick="toggleDataTable('rankDistributionTable')">
                                        <i class="fas fa-table"></i> Data
                                    </button>
                                </div>
                            </div>
                            <div class="bar-chart-container">
                                <canvas id="rankDistributionChart"></canvas>
                            </div>
                            <div id="rankDistributionTable" class="data-table-container" style="display: none;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Rank</th>
                                            <th>Count</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalRanks = array_sum(array_column($rankDistributionData, 'count'));
                                        foreach ($rankDistributionData as $data): 
                                            $percentage = $totalRanks > 0 ? round(($data['count'] / $totalRanks) * 100, 2) : 0;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($data['rank_name']); ?></td>
                                            <td><?php echo number_format($data['count']); ?></td>
                                            <td><?php echo $percentage; ?>%</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Gender Distribution Pie Chart -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Gender Distribution</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-controls">
                                <div class="chart-type-selector">
                                    <button class="chart-type-btn active" onclick="changeChartType('genderChart', 'pie')">Pie</button>
                                    <button class="chart-type-btn" onclick="changeChartType('genderChart', 'doughnut')">Donut</button>
                                </div>
                                <div class="chart-actions">
                                    <button class="chart-action-btn" onclick="exportChartData('genderChart', 'gender_distribution_data')">
                                        <i class="fas fa-download"></i> Export
                                    </button>
                                    <button class="chart-action-btn" onclick="toggleDataTable('genderDistributionTable')">
                                        <i class="fas fa-table"></i> Data
                                    </button>
                                </div>
                            </div>
                            <div class="chart-container">
                                <canvas id="genderChart"></canvas>
                            </div>
                            <div id="genderDistributionTable" class="data-table-container" style="display: none;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Gender</th>
                                            <th>Count</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalGender = array_sum(array_column($genderStats, 'count'));
                                        foreach ($genderStats as $data): 
                                            $percentage = $totalGender > 0 ? round(($data['count'] / $totalGender) * 100, 2) : 0;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($data['gender']); ?></td>
                                            <td><?php echo number_format($data['count']); ?></td>
                                            <td><?php echo $percentage; ?>%</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Regional Distribution Bar Chart - Commented out -->
                    <!-- 
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Regional Distribution</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-controls">
                                <div class="chart-type-selector">
                                    <button class="chart-type-btn active" onclick="changeChartType('regionChart', 'bar')">Bar</button>
                                    <button class="chart-type-btn" onclick="changeChartType('regionChart', 'horizontalBar')">Horizontal</button>
                                </div>
                                <div class="chart-actions">
                                    <button class="chart-action-btn" onclick="exportChartData('regionChart', 'regional_distribution_data')">
                                        <i class="fas fa-download"></i> Export
                                    </button>
                                    <button class="chart-action-btn" onclick="toggleDataTable('regionalDistributionTable')">
                                        <i class="fas fa-table"></i> Data
                                    </button>
                                </div>
                            </div>
                            <div class="bar-chart-container">
                                <canvas id="regionChart"></canvas>
                            </div>
                            <div id="regionalDistributionTable" class="data-table-container" style="display: none;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Region</th>
                                            <th>Count</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalRegions = array_sum(array_column($regionStats, 'count'));
                                        foreach ($regionStats as $data): 
                                            $percentage = $totalRegions > 0 ? round(($data['count'] / $totalRegions) * 100, 2) : 0;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($data['region_name']); ?></td>
                                            <td><?php echo number_format($data['count']); ?></td>
                                            <td><?php echo $percentage; ?>%</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    -->
                </div>

                <!-- Small Charts Grid -->
                <div class="small-charts-grid">
                    <!-- Age Distribution -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Age Distribution</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="ageDistributionChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Service Years -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Service Years</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="serviceYearsChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Command Distribution -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Command Distribution</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="commandChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Department Distribution -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Department Distribution</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="departmentChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Location Distribution Card (Present Posting from tbl_employment) -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Present Posting Distribution</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-controls">
                            <div class="chart-type-selector">
                                <button class="chart-type-btn active" onclick="changeChartType('locationDistributionChart', 'bar')">Bar</button>
                                <button class="chart-type-btn" onclick="changeChartType('locationDistributionChart', 'horizontalBar')">Horizontal</button>
                                <button class="chart-type-btn" onclick="changeChartType('locationDistributionChart', 'pie')">Pie</button>
                            </div>
                            <div class="chart-actions">
                                <button class="chart-action-btn" onclick="exportChartData('locationDistributionChart', 'present_posting_distribution_data')">
                                    <i class="fas fa-download"></i> Export
                                </button>
                                <button class="chart-action-btn" onclick="toggleDataTable('locationDistributionTable')">
                                    <i class="fas fa-table"></i> Data
                                </button>
                            </div>
                        </div>
                        <div class="bar-chart-container">
                            <canvas id="locationDistributionChart"></canvas>
                        </div>
                        <div id="locationDistributionTable" class="data-table-container" style="display: none;">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Present Posting</th>
                                        <th>Count</th>
                                        <th>Percentage</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $totalLocations = array_sum(array_column($locationStats, 'count'));
                                    foreach ($locationStats as $data): 
                                        $percentage = $totalLocations > 0 ? round(($data['count'] / $totalLocations) * 100, 2) : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($data['location_name']); ?></td>
                                        <td><?php echo number_format($data['count']); ?></td>
                                        <td><?php echo $percentage; ?>%</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Realtime Update Indicator -->
    <div id="realtimeIndicator" class="realtime-indicator" style="display: none;">
        <i class="fas fa-sync fa-spin"></i>
        <span>Updating...</span>
    </div>

    <script>
    // Chart configuration
    const chartColors = [
        '#1cc88a', '#28a745', '#20c997', '#f6c23e', '#e74a3b',
        '#4e73df', '#36b9cc', '#858796', '#5a5c69', '#2c9faf',
        '#6610f2', '#6f42c1', '#e83e8c', '#fd7e14', '#17a2b8'
    ];

    const barChartColors = [
        'rgba(44, 123, 229, 0.8)',
        'rgba(39, 174, 96, 0.8)',
        'rgba(231, 74, 59, 0.8)',
        'rgba(246, 194, 62, 0.8)',
        'rgba(86, 61, 124, 0.8)',
        'rgba(91, 192, 222, 0.8)',
        'rgba(217, 83, 79, 0.8)',
        'rgba(240, 173, 78, 0.8)',
        'rgba(92, 184, 92, 0.8)',
        'rgba(2, 117, 216, 0.8)'
    ];

    const barBorderColors = [
        'rgba(44, 123, 229, 1)',
        'rgba(39, 174, 96, 1)',
        'rgba(231, 74, 59, 1)',
        'rgba(246, 194, 62, 1)',
        'rgba(86, 61, 124, 1)',
        'rgba(91, 192, 222, 1)',
        'rgba(217, 83, 79, 1)',
        'rgba(240, 173, 78, 1)',
        'rgba(92, 184, 92, 1)',
        'rgba(2, 117, 216, 1)'
    ];

    let charts = {};
    let isUpdating = false;
    let updateInterval = 30000; // 30 seconds

    // Initialize counters with animation
    function animateCounter(element, target) {
        const counter = document.getElementById(element);
        if (!counter) return;
        
        const currentValue = parseInt(counter.textContent.replace(/,/g, '')) || 0;
        if (currentValue === target) return;
        
        let current = currentValue;
        const increment = (target - currentValue) / 100;
        const timer = setInterval(() => {
            current += increment;
            if ((increment > 0 && current >= target) || (increment < 0 && current <= target)) {
                current = target;
                clearInterval(timer);
            }
            counter.textContent = Math.floor(current).toLocaleString();
        }, 20);
    }

    // Create or update chart with better error handling
    function createOrUpdateChart(elementId, data, type = 'pie', options = {}) {
        try {
            const ctx = document.getElementById(elementId);
            if (!ctx) {
                console.error('Chart element not found:', elementId);
                return null;
            }

            // Ensure we have valid data
            if (!data || !data.labels || !data.values || 
                data.labels.length === 0 || data.values.length === 0) {
                
                // Create empty chart with message
                const emptyConfig = {
                    type: 'pie',
                    data: {
                        labels: ['No Data Available'],
                        datasets: [{
                            data: [1],
                            backgroundColor: ['#cccccc'],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                enabled: false
                            }
                        }
                    }
                };
                
                if (charts[elementId]) {
                    charts[elementId].data = emptyConfig.data;
                    charts[elementId].update();
                } else {
                    charts[elementId] = new Chart(ctx.getContext('2d'), emptyConfig);
                }
                return charts[elementId];
            }

            // Special options for bar charts
            const isBarChart = type === 'bar' || type === 'horizontalBar' || type === 'line';
            const isPieChart = type === 'pie' || type === 'doughnut';
            
            const defaultOptions = {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: isPieChart ? 'right' : (isBarChart ? 'top' : 'bottom'),
                        labels: {
                            usePointStyle: isPieChart,
                            padding: 15,
                            font: {
                                size: 11
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                scales: isBarChart ? {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000) {
                                    return (value / 1000).toFixed(1) + 'k';
                                }
                                return value;
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45,
                            minRotation: 0
                        }
                    }
                } : {}
            };

            // Merge custom options
            const chartOptions = Object.assign({}, defaultOptions, options);

            const chartConfig = {
                type: type,
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: data.label || 'Data',
                        data: data.values,
                        backgroundColor: isBarChart ? barChartColors : chartColors,
                        borderColor: isBarChart ? barBorderColors : '#ffffff',
                        borderWidth: isBarChart ? 1 : 1,
                        borderRadius: isBarChart ? 3 : 0,
                        borderSkipped: false
                    }]
                },
                options: chartOptions
            };

            if (charts[elementId]) {
                charts[elementId].data = chartConfig.data;
                charts[elementId].options = chartConfig.options;
                charts[elementId].update();
            } else {
                charts[elementId] = new Chart(ctx.getContext('2d'), chartConfig);
            }
            
            return charts[elementId];
        } catch (error) {
            console.error('Error creating/updating chart:', elementId, error);
            return null;
        }
    }

    // Change chart type dynamically
    function changeChartType(chartId, newType) {
        if (charts[chartId]) {
            // Update chart type
            charts[chartId].config.type = newType;
            
            // Update chart options based on type
            if (newType === 'horizontalBar') {
                charts[chartId].options.indexAxis = 'y';
            } else if (newType === 'bar' || newType === 'line') {
                charts[chartId].options.indexAxis = 'x';
            }
            
            charts[chartId].update();
            
            // Update button states
            const buttons = document.querySelectorAll(`[onclick*="${chartId}"]`);
            buttons.forEach(btn => {
                if (btn.textContent.toLowerCase() === newType.toLowerCase()) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
        }
    }

    // Toggle data table visibility
    function toggleDataTable(tableId) {
        const table = document.getElementById(tableId);
        if (table) {
            table.style.display = table.style.display === 'none' ? 'block' : 'none';
        }
    }

    // Export chart data as CSV
    function exportChartData(chartId, filename) {
        if (charts[chartId]) {
            const chart = charts[chartId];
            const labels = chart.data.labels;
            const data = chart.data.datasets[0].data;
            
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += "Label,Value\n";
            
            labels.forEach((label, index) => {
                csvContent += `"${label}",${data[index]}\n`;
            });
            
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `${filename}_${new Date().toISOString().slice(0,10)}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    // Show realtime indicator
    function showRealtimeIndicator() {
        const indicator = document.getElementById('realtimeIndicator');
        if (indicator) {
            indicator.style.display = 'flex';
            setTimeout(() => {
                indicator.style.display = 'none';
            }, 2000);
        }
    }

    // Initialize dashboard when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Animate initial counters with REAL DATA
        animateCounter('totalPersonnel', <?php echo $totalPersonnel; ?>);
        animateCounter('totalUsers', <?php echo $totalUsers; ?>);
        animateCounter('totalCommands', <?php echo $totalCommands; ?>);
        animateCounter('totalZones', <?php echo $totalZones; ?>);
        animateCounter('totalDepartments', <?php echo count($departmentStats); ?>);
        animateCounter('totalRanks', <?php echo count($rankDistributionData); ?>);
        // animateCounter('totalRegions', <?php echo count($regionStats); ?>); // Commented out
        
        // Initialize charts with REAL DATA
        
        // 1. Rank Distribution Chart
        createOrUpdateChart('rankDistributionChart', {
            label: 'Personnel Count',
            labels: <?php echo $rankLabels; ?>,
            values: <?php echo $rankValues; ?>
        }, 'bar');
        
        // 2. Gender Distribution Chart
        createOrUpdateChart('genderChart', {
            labels: <?php echo $genderLabels; ?>,
            values: <?php echo $genderValues; ?>
        }, 'pie');
        
        // 3. Region Distribution Chart - Commented out
        /*
        createOrUpdateChart('regionChart', {
            label: 'Personnel Count',
            labels: <?php echo $regionLabels; ?>,
            values: <?php echo $regionValues; ?>
        }, 'bar');
        */
        
        // 4. Age Distribution Chart
        createOrUpdateChart('ageDistributionChart', {
            labels: <?php echo $ageLabels; ?>,
            values: <?php echo $ageValues; ?>
        }, 'pie');
        
        // 5. Service Years Chart
        createOrUpdateChart('serviceYearsChart', {
            labels: <?php echo $serviceYearsLabels; ?>,
            values: <?php echo $serviceYearsValues; ?>
        }, 'doughnut');
        
        // 6. Command Distribution Chart
        createOrUpdateChart('commandChart', {
            labels: <?php echo $commandLabels; ?>,
            values: <?php echo $commandValues; ?>
        }, 'pie');
        
        // 7. Department Distribution Chart
        createOrUpdateChart('departmentChart', {
            labels: <?php echo $departmentLabels; ?>,
            values: <?php echo $departmentValues; ?>
        }, 'doughnut');
        
        // 8. Present Posting Distribution Chart (from tbl_employment)
        createOrUpdateChart('locationDistributionChart', {
            label: 'Present Posting Count',
            labels: <?php echo $locationLabels; ?>,
            values: <?php echo $locationValues; ?>
        }, 'bar');
        
        // Update dashboard every 30 seconds
        setInterval(() => {
            showRealtimeIndicator();
            // In a real implementation, you would fetch new data here
            // For now, just show the indicator
        }, updateInterval);
        
        // Hide loading spinner
        document.getElementById('dashboardSpinner').style.display = 'none';
    });
    
    </script>
    
</body>
</html>
<?php include 'includes/footer.php'; ?>