<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/auth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Generate CAPTCHA code if not already set
if (!isset($_SESSION['captcha_code'])) {
    $_SESSION['captcha_code'] = generateCaptchaCode();
}

// Function to generate CAPTCHA code
function generateCaptchaCode($length = 6) {
    $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $captcha = '';
    for ($i = 0; $i < $length; $i++) {
        $captcha .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $captcha;
}

// Function to generate CAPTCHA image
function generateCaptchaImage($code) {
    $width = 180;
    $height = 60;
    
    $image = imagecreatetruecolor($width, $height);
    
    // Background color (light gray)
    $bgColor = imagecolorallocate($image, 240, 240, 240);
    imagefill($image, 0, 0, $bgColor);
    
    // Add random noise
    for ($i = 0; $i < 500; $i++) {
        $noiseColor = imagecolorallocate($image, rand(150, 220), rand(150, 220), rand(150, 220));
        imagesetpixel($image, rand(0, $width), rand(0, $height), $noiseColor);
    }
    
    // Draw random lines
    for ($i = 0; $i < 5; $i++) {
        $lineColor = imagecolorallocate($image, rand(100, 200), rand(100, 200), rand(100, 200));
        imageline($image, rand(0, $width), rand(0, $height), rand(0, $width), rand(0, $height), $lineColor);
    }
    
    // Font settings
    $fontFile = __DIR__ . '/assets/fonts/arial.ttf';
    if (!file_exists($fontFile)) {
        // Use GD default font if custom font not found
        for ($i = 0; $i < strlen($code); $i++) {
            $charColor = imagecolorallocate($image, rand(0, 100), rand(0, 100), rand(0, 100));
            imagestring($image, 5, 20 + ($i * 25) + rand(-5, 5), 15 + rand(-10, 10), $code[$i], $charColor);
        }
    } else {
        // Use TrueType font
        for ($i = 0; $i < strlen($code); $i++) {
            $charColor = imagecolorallocate($image, rand(0, 100), rand(0, 100), rand(0, 100));
            $angle = rand(-20, 20);
            $fontSize = rand(22, 26);
            $x = 20 + ($i * 25) + rand(-5, 5);
            $y = 40 + rand(-5, 5);
            
            imagettftext($image, $fontSize, $angle, $x, $y, $charColor, $fontFile, $code[$i]);
        }
    }
    
    // Output image
    header('Content-Type: image/png');
    imagepng($image);
    imagedestroy($image);
    exit();
}

// Handle CAPTCHA image request
if (isset($_GET['captcha'])) {
    if (isset($_SESSION['captcha_code'])) {
        generateCaptchaImage($_SESSION['captcha_code']);
    }
    exit();
}

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $username = sanitizeInput($_POST['username']);
        $password = sanitizeInput($_POST['password']);
        $captchaInput = isset($_POST['captcha']) ? sanitizeInput($_POST['captcha']) : '';
        
        // CAPTCHA validation
        if (!isset($_SESSION['captcha_code']) || empty($captchaInput)) {
            $error = "Please enter the CAPTCHA code";
        } elseif (strtoupper($captchaInput) !== strtoupper($_SESSION['captcha_code'])) {
            $error = "Invalid CAPTCHA code. Please try again.";
            // Regenerate CAPTCHA on failed attempt
            $_SESSION['captcha_code'] = generateCaptchaCode();
        } elseif (loginUser($username, $password)) {
            // Clear CAPTCHA on successful login
            unset($_SESSION['captcha_code']);
            header('Location: dashboard.php');
            exit();
        } else {
            $error = "Invalid username or password";
            // Regenerate CAPTCHA on failed login
            $_SESSION['captcha_code'] = generateCaptchaCode();
        }
    } catch (Exception $e) {
        $error = "System Error: " . $e->getMessage();
        // Regenerate CAPTCHA on error
        $_SESSION['captcha_code'] = generateCaptchaCode();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIS Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: 
                linear-gradient(135deg, rgba(44, 62, 80, 0.85) 0%, rgba(39, 174, 96, 0.85) 100%),
                url('assets/images/tech_building.jpg') center/cover no-repeat;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                linear-gradient(135deg, rgba(44, 62, 80, 0.7) 0%, rgba(39, 174, 96, 0.7) 100%),
                url('assets/images/tech_building.jpg') center/cover no-repeat;
            z-index: -1;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 400px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .logo {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .logo-image {
            width: 100px;
            height: 100px;
            margin: 0 auto 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .logo-title {
            color: #2c3e50;
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 0.3rem;
            line-height: 1.2;
        }
        .logo-subtitle {
            color: #27ae60;
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 0;
            line-height: 1.2;
        }
        .form-group {
            margin-bottom: 1.2rem;
        }
        label {
            display: block;
            margin-bottom: 0.4rem;
            font-weight: 600;
            color: #333;
            font-size: 0.9rem;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 0.95rem;
            background: rgba(255, 255, 255, 0.9);
        }
        input:focus {
            outline: none;
            border-color: #27ae60;
            box-shadow: 0 0 0 2px rgba(39, 174, 96, 0.2);
            background: white;
        }
        .btn-login {
            width: 100%;
            padding: 10px;
            background: #27ae60;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 0.95rem;
            cursor: pointer;
            margin-top: 0.5rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        .btn-login:hover {
            background: #219a52;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 8px 10px;
            border-radius: 5px;
            margin-bottom: 1rem;
            border: 1px solid #f5c6cb;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }
        .footer-info {
            background: rgba(248, 249, 250, 0.8);
            color: #6c757d;
            padding: 8px 10px;
            border-radius: 5px;
            margin-top: 1rem;
            border: 1px solid rgba(233, 236, 239, 0.5);
            font-size: 0.8rem;
            text-align: center;
            font-style: italic;
        }
        .login-header {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .form-container {
            margin-bottom: 0.5rem;
        }
        
        /* Additional styles for CAPTCHA and form elements */
        .password-container {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
            transition: color 0.3s ease;
            font-size: 0.9rem;
            background: none;
            border: none;
            z-index: 2;
        }
        .captcha-container {
            margin-bottom: 1.2rem;
        }
        .captcha-image-container {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.5rem;
        }
        .captcha-image {
            border: 2px solid #ddd;
            border-radius: 5px;
            padding: 3px;
            background-color: #f8f9fa;
            cursor: pointer;
            max-height: 50px;
        }
        .captcha-input-container {
            display: flex;
            gap: 8px;
        }
        .captcha-input {
            flex: 1;
        }
        .btn-refresh-captcha {
            background-color: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 0 12px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .btn-refresh-captcha:hover {
            background-color: #5a6268;
        }
        .captcha-help {
            font-size: 0.75rem;
            color: #666;
            text-align: center;
            margin-top: 5px;
        }
        
        /* Fallback if image doesn't load */
        .no-background-image body {
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%) !important;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <div class="logo-image">
                <img src="assets/images/logo.png" alt="NIS Logo" onerror="this.style.display='none'">
            </div>
            <div class="logo-title">NISPPMS</div>
            <div class="logo-subtitle">NIS Personnel Posting Management System</div>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error">
                <i class="bi bi-exclamation-triangle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="loginForm">
            <div class="form-group">
                <input type="text" id="username" name="username" 
                       placeholder="Username" required autocomplete="username">
            </div>
            
            <div class="form-group password-container">
                <input type="password" id="password" name="password" 
                       placeholder="Password" required autocomplete="current-password">
                <button type="button" class="password-toggle" id="togglePassword">
                    👁️
                </button>
            </div>
            
            <div class="form-group captcha-container">
                <div class="captcha-image-container">
                    <img src="?captcha=1&t=<?php echo time(); ?>" 
                         alt="CAPTCHA Code" 
                         class="captcha-image" 
                         id="captchaImage"
                         onclick="refreshCaptcha()"
                         title="Click to refresh">
                </div>
                <div class="captcha-input-container">
                    <input type="text" class="captcha-input" 
                           id="captcha" name="captcha" 
                           placeholder="Enter CAPTCHA code" 
                           required
                           maxlength="6"
                           autocomplete="off">
                    <button type="button" class="btn-refresh-captcha" onclick="refreshCaptcha()" 
                            title="Refresh CAPTCHA">
                        ↻
                    </button>
                </div>
                <div class="captcha-help">
                    <small>Enter the code shown in the image above (case-insensitive)</small>
                </div>
            </div>
            
            <button type="submit" class="btn-login">Sign In</button>
        </form>
        
        <div class="footer-info">
            <small>Designed and Developed by NIS Web Team.</small>
        </div>
    </div>

    <script>
        // Password toggle visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                this.textContent = '👁️';
            }
        });
        
        // CAPTCHA refresh function
        function refreshCaptcha() {
            const captchaImage = document.getElementById('captchaImage');
            // Add timestamp to prevent caching
            captchaImage.src = '?captcha=1&t=' + new Date().getTime();
            // Clear the CAPTCHA input field
            document.getElementById('captcha').value = '';
            // Focus on CAPTCHA input
            document.getElementById('captcha').focus();
        }
        
        // Auto-refresh CAPTCHA every 5 minutes
        setInterval(refreshCaptcha, 300000);
        
        // Form submission handler
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const captchaInput = document.getElementById('captcha').value.trim();
            if (!captchaInput) {
                e.preventDefault();
                alert('Please enter the CAPTCHA code');
                document.getElementById('captcha').focus();
            }
        });
        
        // Focus on username field on page load
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('username').focus();
        });
        
        // Auto-uppercase CAPTCHA input
        document.getElementById('captcha').addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
        
        // Check if background image loaded successfully
        document.addEventListener('DOMContentLoaded', function() {
            const bgImage = new Image();
            bgImage.src = 'images/nis_tech_building.png';
            bgImage.onerror = function() {
                document.body.classList.add('no-background-image');
            };
        });
    </script>
</body>
</html>