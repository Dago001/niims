<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
session_start();

// Include required files
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get user information for sidebar
$user = [];
$totalPersonnel = 0;
$totalUsers = 0;

try {
    // Get user information
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("
            SELECT u.*, r.name as role_name
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    }

    // Get statistics for sidebar
    $totalPersonnel = $pdo->query("SELECT COUNT(*) as count FROM tbl_emppersonal")->fetch()['count'];
    $totalUsers = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];

} catch (Exception $e) {
    error_log("Error getting user/sidebar data: " . $e->getMessage());
}

// Set safe defaults for user data
if (empty($user)) {
    $user = [
        'username' => $_SESSION['username'] ?? 'User',
        'full_name' => $_SESSION['username'] ?? 'User',
        'role_name' => 'User'
    ];
}

// Initialize variables
$serviceNo = '';
$current_posting_data = null;
$employment_data = [];
$personal_data = [];
$error = '';
$success = '';
$posting_history = [];

// Database configuration for current_posting table
$db_config = [
    'niimscom_idcard' => [
        'host' => 'localhost',
        'dbname' => 'niimscom_idcard',
        'username' => 'niimscom_admin',
        'password' => '$@muel@0deh'
    ]
];

// Get serviceNo from URL parameter
if (!isset($_GET['serviceNo'])) {
    header('Location: search.php');
    exit();
}

$serviceNo = sanitizeInput($_GET['serviceNo']);

// Create database connection for current_posting table
try {
    $pdo_idcard = new PDO(
        "mysql:host={$db_config['niimscom_idcard']['host']};dbname={$db_config['niimscom_idcard']['dbname']};charset=utf8mb4",
        $db_config['niimscom_idcard']['username'],
        $db_config['niimscom_idcard']['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Create tables if they don't exist
    $createCurrentPostingTableSQL = "
        CREATE TABLE IF NOT EXISTS `current_posting` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `serviceNo` VARCHAR(50) NOT NULL,
            `posting_location` TEXT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `unique_serviceNo` (`serviceNo`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    $pdo_idcard->exec($createCurrentPostingTableSQL);
    
    $createHistoryTableSQL = "
        CREATE TABLE IF NOT EXISTS `posting_history` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `serviceNo` VARCHAR(50) NOT NULL,
            `posting_location` TEXT NOT NULL,
            `posting_date` DATE NOT NULL,
            `posting_type` ENUM('initial', 'transfer', 'current') DEFAULT 'transfer',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX `idx_serviceNo` (`serviceNo`),
            INDEX `idx_posting_date` (`posting_date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    $pdo_idcard->exec($createHistoryTableSQL);
    
} catch (PDOException $e) {
    $error = "Database connection error: " . $e->getMessage();
}

// Fetch current posting data
if (empty($error)) {
    try {
        // Fetch current posting
        $stmt = $pdo_idcard->prepare("
            SELECT posting_location, updated_at 
            FROM current_posting 
            WHERE serviceNo = ?
        ");
        $stmt->execute([$serviceNo]);
        $current_posting_data = $stmt->fetch();
        
        // Fetch posting history
        $historyStmt = $pdo_idcard->prepare("
            SELECT posting_location, posting_date, posting_type, created_at
            FROM posting_history 
            WHERE serviceNo = ? 
            ORDER BY posting_date DESC, created_at DESC
        ");
        $historyStmt->execute([$serviceNo]);
        $posting_history = $historyStmt->fetchAll();
        
    } catch (PDOException $e) {
        $error = "Error fetching posting data: " . $e->getMessage();
    }
}

// Fetch employment and personal data from main database
try {
    // Fetch employment data
    $stmt = $pdo->prepare("
        SELECT 
            e.serviceNo,
            e.dofa,
            e.dopa,
            e.presentPosting,
            e.currentRank,
            e.empStatus
        FROM tbl_employment e
        WHERE e.serviceNo = ?
    ");
    $stmt->execute([$serviceNo]);
    $employment_data = $stmt->fetch();
    
    if (!$employment_data) {
        $error = "Employment record not found for service number: " . htmlspecialchars($serviceNo);
    } else {
        // Fetch personal data
        $stmt = $pdo->prepare("
            SELECT surname, firstName, middleName 
            FROM tbl_emppersonal 
            WHERE serviceNo = ?
        ");
        $stmt->execute([$serviceNo]);
        $personal_data = $stmt->fetch();
    }
    
} catch (PDOException $e) {
    $error = "Error fetching employment records: " . $e->getMessage();
}

// Define complete Nigeria Immigration Service formations structure
$nis_formations = [
    // SHQ - Service Headquarters
    'SHQ' => [
        'SHQ' => 'NIS Headquarters, Abuja',
        'CGIS' => 'Comptroller General of Immigration Office',
        'VRD' => 'Visa and Residency Directorate',
        'POTD' => 'Passport and Other Travel Document Directorate',
        'FAD' => 'Finance and Account Directorate',
        'PRSD' => 'Planning Research and Statistics Directorate',
        'ICD' => 'Investigation & Compliance Directorate',
        'MD' => 'Migration Directorate',
        'BMD' => 'Border Management Directorate',
        'HRMD' => 'Human Resource Management Directorate',
        'WLD' => 'Works And Logistics Directorate',
        'ICTD' => 'ICT And Cyber Security Directorate'
    ],
    
    // ZONE A
    'ZONE A' => [
        'Zone A HQ' => 'Zone A Headquarters, Ikeja',
        'LASC' => 'Lagos State Command',
        'OGSC' => 'Ogun State Command',
        'LASPC' => 'Lagos Seaport and Marine Command',
        'SEME' => 'Seme Border Command',
        'IDBC' => 'Idiroko Border Command',
        'MMIA' => 'Murtala Muhamed International Airport Command',
        'LABPC' => 'Lagos State Border Patrol Command, Seme',
        'LAPC' => 'Lagos Passport Command'
    ],
    
    // ZONE B
    'ZONE B' => [
        'Zone B HQ' => 'Zone B Headquarters, Kaduna',
        'KNSC' => 'Kano State Command',
        'KDSC' => 'Kaduna State Command',
        'KTSC' => 'Katsina State Command',
        'ZMSC' => 'Zamfara State Command',
        'SOSC' => 'Sokoto State Command',
        'JGSC' => 'Jigawa State Command',
        'MAKIA' => 'Mallam Aminu Kano International Airport Command',
        'ILBC' => 'Illela Border Command',
        'JIBC' => 'Jibia Border Command',
        'ITSK' => 'Immigration Training School Kano',
        'ICSC' => 'Immigration Command and Staff College'
    ],
    
    // ZONE C
    'ZONE C' => [
        'Zone C HQ' => 'Zone C Headquarters, Bauchi',
        'ADSC' => 'Adamawa State Command',
        'BASC' => 'Bauchi State Command',
        'BOSC' => 'Borno State Command',
        'GMSC' => 'Gombe State Command',
        'PLSC' => 'Plateau State Command',
        'YBSC' => 'Yobe State Command'
    ],
    
    // ZONE D
    'ZONE D' => [
        'Zone D HQ' => 'Zone D Headquarters, Minna',
        'FCTC' => 'FCT Command',
        'NGSC' => 'Niger State Command',
        'KBSC' => 'Kebbi State Command',
        'RMAT' => 'Regional Migration Academy, Tuga',
        'KWSC' => 'Kwara State Command'
    ],
    
    // ZONE E
    'ZONE E' => [
        'Zone E HQ' => 'Zone E Headquarters, Owerri',
        'IMSC' => 'Imo State Command',
        'RVSC' => 'Rivers State Command',
        'CRSC' => 'Cross River State Command',
        'EBSC' => 'Ebonyi State Command',
        'AKSC' => 'Akwa Ibom State Command',
        'NITSOL' => 'Nigeria Immigration Training School Orlu',
        'RVMC' => 'Rivers Marine Command Onne',
        'MFBC' => 'Mfum Border Command',
        'NITSA' => 'Nigeria Immigration Training School Ahoada'
    ],
    
    // ZONE F
    'ZONE F' => [
        'Zone F HQ' => 'Zone F Headquarters, Ibadan',
        'OYSC' => 'Oyo State Command',
        'EKSC' => 'Ekiti State Command',
        'ODSC' => 'Ondo State Command',
        'OSSC' => 'Osun State Command'
    ],
    
    // ZONE G
    'ZONE G' => [
        'Zone G HQ' => 'Zone G Headquarters, Benin',
        'EDSC' => 'Edo State Command',
        'ANSC' => 'Anambra State Command',
        'DTSC' => 'Delta State Command',
        'ENSC' => 'Enugu State Command',
        'BYSC' => 'Bayelsa State Command'
    ],
    
    // ZONE H
    'ZONE H' => [
        'Zone H HQ' => 'Zone H Headquarters, Makurdi',
        'NASC' => 'Nasarawa State Command',
        'BNSC' => 'Benue State Command',
        'KGSC' => 'Kogi State Command',
        'TRSC' => 'Taraba State Command'
    ]
];

// Flatten the array for the select options
$nis_formations_flat = [];
foreach ($nis_formations as $zone => $formations) {
    foreach ($formations as $code => $name) {
        $nis_formations_flat[$code] = $name;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $presentPosting = sanitizeInput($_POST['presentPosting']);
    $posting_date = sanitizeInput($_POST['posting_date']);
    
    // Validate posting date
    if (empty($posting_date)) {
        $error = "Posting date is required";
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $posting_date)) {
        $error = "Invalid date format. Use YYYY-MM-DD";
    } else {
        // Validate date is not in the future
        $posting_timestamp = strtotime($posting_date);
        $today_timestamp = strtotime(date('Y-m-d'));
        if ($posting_timestamp > $today_timestamp) {
            $error = "Posting date cannot be in the future";
        }
    }
    
    // Check if custom posting is used
    if (isset($_POST['presentPosting']) && $_POST['presentPosting'] === 'other' && isset($_POST['customPosting'])) {
        $presentPosting = sanitizeInput($_POST['customPosting']);
    }
    
    // Store old posting value for comparison
    $oldPosting = '';
    if ($current_posting_data) {
        $oldPosting = $current_posting_data['posting_location'];
    } elseif ($employment_data) {
        $oldPosting = $employment_data['presentPosting'];
    }
    
    $postingUpdated = false;
    $postingAction = '';
    $postingError = '';
    
    if (empty($error)) {
        try {
            // Start transaction for data consistency
            $pdo_idcard->beginTransaction();
            
            // Check if record exists in current_posting
            $checkStmt = $pdo_idcard->prepare("
                SELECT COUNT(*) as count FROM current_posting WHERE serviceNo = ?
            ");
            $checkStmt->execute([$serviceNo]);
            $result = $checkStmt->fetch();
            
            if ($result['count'] > 0) {
                // Update existing record
                $updateStmt = $pdo_idcard->prepare("
                    UPDATE current_posting 
                    SET posting_location = ?, updated_at = NOW()
                    WHERE serviceNo = ?
                ");
                $updateStmt->execute([$presentPosting, $serviceNo]);
                $postingUpdated = true;
                $postingAction = "updated";
            } else {
                // Insert new record
                $insertStmt = $pdo_idcard->prepare("
                    INSERT INTO current_posting (serviceNo, posting_location, created_at, updated_at)
                    VALUES (?, ?, NOW(), NOW())
                ");
                $insertStmt->execute([$serviceNo, $presentPosting]);
                $postingUpdated = true;
                $postingAction = "created";
            }
            
            // **CRITICAL: Add to posting_history if posting has changed**
            if ($postingUpdated && (!empty($oldPosting) && $oldPosting !== $presentPosting)) {
                // First, update any existing 'current' type entries to 'transfer'
                $updateOldCurrentStmt = $pdo_idcard->prepare("
                    UPDATE posting_history 
                    SET posting_type = 'transfer' 
                    WHERE serviceNo = ? AND posting_type = 'current'
                ");
                $updateOldCurrentStmt->execute([$serviceNo]);
                
                // Check if this posting already exists in history for the selected date
                $checkHistoryStmt = $pdo_idcard->prepare("
                    SELECT COUNT(*) as count 
                    FROM posting_history 
                    WHERE serviceNo = ? AND posting_location = ? 
                    AND posting_date = ?
                ");
                $checkHistoryStmt->execute([$serviceNo, $presentPosting, $posting_date]);
                $historyResult = $checkHistoryStmt->fetch();
                
                if ($historyResult['count'] == 0) {
                    // Determine posting type
                    $posting_type = 'transfer';
                    if (empty($posting_history)) {
                        $posting_type = 'initial';
                    }
                    
                    // Add to posting_history
                    $historyStmt = $pdo_idcard->prepare("
                        INSERT INTO posting_history (serviceNo, posting_location, posting_date, posting_type)
                        VALUES (?, ?, ?, ?)
                    ");
                    $historyStmt->execute([$serviceNo, $presentPosting, $posting_date, $posting_type]);
                    
                    // Mark the new one as current
                    $updateNewCurrentStmt = $pdo_idcard->prepare("
                        UPDATE posting_history 
                        SET posting_type = 'current' 
                        WHERE serviceNo = ? AND posting_location = ? 
                        AND posting_date = ?
                        ORDER BY id DESC LIMIT 1
                    ");
                    $updateNewCurrentStmt->execute([$serviceNo, $presentPosting, $posting_date]);
                }
            } elseif ($postingUpdated && empty($oldPosting)) {
                // This is the first posting entry
                $historyStmt = $pdo_idcard->prepare("
                    INSERT INTO posting_history (serviceNo, posting_location, posting_date, posting_type)
                    VALUES (?, ?, ?, 'initial')
                ");
                $historyStmt->execute([$serviceNo, $presentPosting, $posting_date]);
                
                // Mark as current
                $updateNewCurrentStmt = $pdo_idcard->prepare("
                    UPDATE posting_history 
                    SET posting_type = 'current' 
                    WHERE serviceNo = ? AND posting_location = ? 
                    AND posting_date = ?
                ");
                $updateNewCurrentStmt->execute([$serviceNo, $presentPosting, $posting_date]);
            }
            
            // Commit transaction
            $pdo_idcard->commit();
            
            // Success message
            if (!empty($oldPosting) && $oldPosting !== $presentPosting) {
                $success = "Present posting changed from '" . 
                           htmlspecialchars($oldPosting) . "' to '" . 
                           htmlspecialchars($presentPosting) . "'<br>";
                $success .= "Effective Date: " . date('d/m/Y', strtotime($posting_date)) . "<br>";
                $success .= "Posting record " . $postingAction . " ";
            } else {
                $success = "Posting record " . $postingAction . " ";
            }
            
            // Refresh the data
            $stmt = $pdo_idcard->prepare("
                SELECT posting_location, updated_at 
                FROM current_posting 
                WHERE serviceNo = ?
            ");
            $stmt->execute([$serviceNo]);
            $current_posting_data = $stmt->fetch();
            
            // Refresh posting history
            $historyStmt = $pdo_idcard->prepare("
                SELECT posting_location, posting_date, posting_type, created_at
                FROM posting_history 
                WHERE serviceNo = ? 
                ORDER BY posting_date DESC, created_at DESC
            ");
            $historyStmt->execute([$serviceNo]);
            $posting_history = $historyStmt->fetchAll();
            
        } catch (PDOException $e) {
            // Rollback transaction on error
            try {
                $pdo_idcard->rollBack();
            } catch (PDOException $rollbackError) {
                // Ignore rollback errors
            }
            
            $error = "Error updating posting: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIS Personnel Posting Management System - Edit Posting</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* CSS Reset */
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        /* Body styling */
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: 
                linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(39, 174, 96, 0.9) 100%),
                url('assets/images/tech_building.jpg') center/cover no-repeat fixed;
            min-height: 100vh;
            color: #333;
        }
        
        /* Header styling */
        .header-container {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 0.8rem 2rem;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(5px);
            border-bottom: 2px solid #27ae60;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .logo-title-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .header-logo {
            height: 50px;
            width: auto;
            object-fit: contain;
        }
        
        .system-title {
            color: #2c3e50;
            font-size: 1.4rem;
            font-weight: 800;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-profile {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        /* Main layout with sidebar */
        .main-layout {
            display: flex;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            gap: 20px;
            min-height: calc(100vh - 80px);
        }
        
        /* Sidebar styling */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
            color: #ecf0f1;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
            z-index: 100;
            flex-shrink: 0;
        }
        
        /* Content area styling */
        .content-area {
            flex: 1;
            background: rgba(255, 255, 255, 0.98);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            padding: 2rem;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(39, 174, 96, 0.1);
            overflow-x: auto;
        }
        
        /* Page header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .page-title-section {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex: 1;
        }
        
        .back-to-dashboard {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.6rem 1.2rem;
            background: #27ae60;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            white-space: nowrap;
        }
        
        .back-to-dashboard:hover {
            background: #219a52;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(39, 174, 96, 0.3);
        }
        
        .page-title {
            color: #2c3e50;
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
            overflow: hidden;
            border: 1px solid rgba(39, 174, 96, 0.1);
        }
        
        .card-header {
            background: linear-gradient(135deg, #2c3e50 0%, #27ae60 100%);
            color: white;
            padding: 1.2rem 1.5rem;
            font-weight: 600;
            font-size: 1.2rem;
            border: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* Personal info box */
        .personal-info {
            background: rgba(39, 174, 96, 0.05);
            border-left: 4px solid #27ae60;
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        
        .info-title {
            color: #2c3e50;
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        /* Posting history box */
        .posting-history-box {
            background: rgba(155, 89, 182, 0.05);
            border-left: 4px solid #9b59b6;
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        
        .history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .history-table th {
            background: rgba(155, 89, 182, 0.1);
            padding: 0.8rem;
            text-align: left;
            font-weight: 600;
            color: #7d3c98;
            border: none;
        }
        
        .history-table td {
            padding: 0.8rem;
            border-bottom: 1px solid #e0e0e0;
            vertical-align: middle;
        }
        
        .history-table tr:hover {
            background: rgba(155, 89, 182, 0.03);
        }
        
        .badge {
            display: inline-block;
            padding: 0.25em 0.4em;
            font-size: 75%;
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }
        
        .bg-primary { background-color: #007bff !important; color: white; }
        .bg-success { background-color: #28a745 !important; color: white; }
        .bg-info { background-color: #17a2b8 !important; color: white; }
        .bg-secondary { background-color: #6c757d !important; color: white; }
        
        /* Form styling */
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .required::after {
            content: " *";
            color: #dc3545;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #27ae60;
            box-shadow: 0 0 0 3px rgba(39, 174, 96, 0.2);
        }
        
        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 1em;
            padding-right: 2.5rem;
        }
        
        .mb-3 {
            margin-bottom: 1rem;
        }
        
        .mt-2 {
            margin-top: 0.5rem;
        }
        
        .mt-4 {
            margin-top: 1.5rem;
        }
        
        /* Form grid layout */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        /* Date container styling */
        .date-container {
            background: rgba(241, 196, 15, 0.1);
            border: 1px solid rgba(241, 196, 15, 0.3);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .date-container h4 {
            color: #f39c12;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .date-hint {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: rgba(241, 196, 15, 0.2);
            border-radius: 6px;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            color: #856404;
        }
        
        /* Alerts */
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #721c24;
            border-left-color: #dc3545;
        }
        
        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            color: #155724;
            border-left-color: #27ae60;
        }
        
        .alert-warning {
            background: rgba(255, 193, 7, 0.1);
            color: #856404;
            border-left-color: #ffc107;
        }
        
        .alert-info {
            background: rgba(23, 162, 184, 0.1);
            color: #0c5460;
            border-left-color: #17a2b8;
        }
        
        /* Zone grouping styling for select options */
        optgroup {
            font-weight: bold;
            color: #2c3e50;
            background: #f8f9fa;
        }
        
        optgroup option {
            font-weight: normal;
            color: #495057;
            padding-left: 20px;
        }
        
        /* Buttons */
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            text-align: center;
            white-space: nowrap;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(108, 117, 125, 0.3);
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #219a52;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(39, 174, 96, 0.3);
        }
        
        .btn-warning {
            background: #f39c12;
            color: white;
        }
        
        .btn-warning:hover {
            background: #d68910;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(243, 156, 18, 0.3);
        }
        
        /* Helper text */
        .text-muted {
            color: #6c757d !important;
            font-size: 0.85rem;
        }
        
        .text-center {
            text-align: center;
        }
        
        /* Responsive Design */
        @media (max-width: 992px) {
            .main-layout {
                flex-direction: column;
                padding: 15px;
            }
            
            .sidebar {
                width: 100%;
                max-height: 400px;
                overflow-y: auto;
            }
            
            .content-area {
                padding: 1.5rem;
            }
            
            .page-header {
                flex-direction: column;
                align-items: stretch;
            }
        }
        
        @media (max-width: 768px) {
            body {
                padding: 0;
            }
            
            .header-container {
                padding: 0.8rem 1rem;
            }
            
            .header-logo {
                height: 40px;
            }
            
            .system-title {
                font-size: 1.1rem;
            }
            
            .main-layout {
                padding: 10px;
            }
            
            .content-area {
                padding: 1.2rem;
            }
            
            .page-title {
                font-size: 1.5rem;
            }
            
            .card-body {
                padding: 1.2rem;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header-container">
        <div class="header-content">
            <div class="logo-title-container">
                <img src="assets/images/logo.png" alt="NIS Logo" class="header-logo">
                <h1 class="system-title">NIS Personnel Posting Management System</h1>
            </div>
            <div class="user-info">
                <div class="user-profile">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></strong><br>
                    <small><?php echo htmlspecialchars($user['role_name']); ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Layout with Sidebar -->
    <div class="main-layout">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>

        <!-- Main Content Area -->
        <div class="content-area">
            <!-- Page Header -->
            <div class="page-header">
                <div class="page-title-section">
                    
                    <h2 class="page-title">Update Posting</h2>
                </div>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if ($employment_data && $personal_data): ?>
                <!-- Personal Information -->
                <div class="personal-info">
                    <h3 class="info-title">
                        <i class="fas fa-user"></i> Personnel Details
                    </h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                        <div>
                            <strong>Service Number:</strong><br>
                            <?php echo htmlspecialchars($employment_data['serviceNo']); ?>
                        </div>
                        <div>
                            <strong>Full Name:</strong><br>
                            <?php 
                            echo htmlspecialchars($personal_data['surname']) . ' ' . 
                                 htmlspecialchars($personal_data['firstName']) . ' ' . 
                                 htmlspecialchars($personal_data['middleName']);
                            ?>
                        </div>
                        <div>
                            <strong>Current Rank:</strong><br>
                            <?php echo htmlspecialchars($employment_data['currentRank'] ?? 'N/A'); ?>
                        </div>
                    </div>
                </div>

                <!-- Current Posting Status -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-map-marker-alt"></i> Current Posting Status
                    </div>
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                            <div>
                                <h4 style="color: #27ae60; margin-bottom: 0.5rem;">
                                    <i class="fas fa-address-card"></i> Employment Record
                                </h4>
                                <div style="background: rgba(52, 152, 219, 0.1); padding: 1rem; border-radius: 8px;">
                                    <strong>Original Posting:</strong><br>
                                    <?php echo htmlspecialchars($employment_data['presentPosting'] ?? 'Not set'); ?>
                                </div>
                            </div>
                            <div>
                                <h4 style="color: #f39c12; margin-bottom: 0.5rem;">
                                    <i class="fas fa-sync-alt"></i> Current Posting 
                                </h4>
                                <div style="background: rgba(243, 156, 18, 0.1); padding: 1rem; border-radius: 8px;">
                                    <?php if ($current_posting_data): ?>
                                        <strong>Current Location:</strong><br>
                                        <?php echo htmlspecialchars($current_posting_data['posting_location']); ?><br>
                                        <small class="text-muted">
                                            <i class="fas fa-clock"></i> Last updated: <?php echo $current_posting_data['updated_at']; ?>
                                        </small>
                                    <?php else: ?>
                                        <em class="text-muted">No current posting record found</em><br>
                                        <small class="text-muted">Will be created on update</small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Edit Posting Form -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-edit"></i> Update Posting Location
                    </div>
                    <div class="card-body">
                        <form method="POST" id="postingForm">
                            <div class="form-grid">
                                <!-- Posting Location Section -->
                                <div>
                                    <div class="mb-3">
                                        <label class="form-label required">New Posting Location</label>
                                        <select class="form-control" name="presentPosting" id="presentPostingSelect" required>
                                            <option value="">Select Formation/Posting Location</option>
                                            
                                            <!-- SHQ - Service Headquarters -->
                                            <optgroup label="SHQ - Service Headquarters">
                                                <?php foreach ($nis_formations['SHQ'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE A -->
                                            <optgroup label="ZONE A">
                                                <?php foreach ($nis_formations['ZONE A'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE B -->
                                            <optgroup label="ZONE B">
                                                <?php foreach ($nis_formations['ZONE B'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE C -->
                                            <optgroup label="ZONE C">
                                                <?php foreach ($nis_formations['ZONE C'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE D -->
                                            <optgroup label="ZONE D">
                                                <?php foreach ($nis_formations['ZONE D'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE E -->
                                            <optgroup label="ZONE E">
                                                <?php foreach ($nis_formations['ZONE E'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE F -->
                                            <optgroup label="ZONE F">
                                                <?php foreach ($nis_formations['ZONE F'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE G -->
                                            <optgroup label="ZONE G">
                                                <?php foreach ($nis_formations['ZONE G'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- ZONE H -->
                                            <optgroup label="ZONE H">
                                                <?php foreach ($nis_formations['ZONE H'] as $code => $name): ?>
                                                    <option value="<?php echo htmlspecialchars($name); ?>"
                                                        <?php 
                                                        $currentPostingValue = '';
                                                        if ($current_posting_data) {
                                                            $currentPostingValue = $current_posting_data['posting_location'];
                                                        } else {
                                                            $currentPostingValue = $employment_data['presentPosting'];
                                                        }
                                                        echo ($currentPostingValue == $name) ? 'selected' : ''; 
                                                        ?>>
                                                        <?php echo htmlspecialchars($name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            
                                            <!-- Custom option for other postings -->
                                            <optgroup label="Other Postings">
                                                <option value="other" 
                                                    <?php 
                                                    $currentPostingValue = '';
                                                    if ($current_posting_data) {
                                                        $currentPostingValue = $current_posting_data['posting_location'];
                                                    } else {
                                                        $currentPostingValue = $employment_data['presentPosting'];
                                                    }
                                                    $found = false;
                                                    foreach ($nis_formations_flat as $code => $name) {
                                                        if ($currentPostingValue == $name) {
                                                            $found = true;
                                                            break;
                                                        }
                                                    }
                                                    echo (!$found && !empty($currentPostingValue)) ? 'selected' : ''; 
                                                    ?>>
                                                    Other (Specify below)
                                                </option>
                                            </optgroup>
                                        </select>
                                        <div class="mt-2" id="customPostingContainer" 
                                             style="<?php 
                                             $currentPostingValue = '';
                                             if ($current_posting_data) {
                                                 $currentPostingValue = $current_posting_data['posting_location'];
                                             } else {
                                                 $currentPostingValue = $employment_data['presentPosting'];
                                             }
                                             $found = false;
                                             foreach ($nis_formations_flat as $code => $name) {
                                                 if ($currentPostingValue == $name) {
                                                     $found = true;
                                                     break;
                                                 }
                                             }
                                             echo (!$found && !empty($currentPostingValue)) ? '' : 'display: none;'; 
                                             ?>">
                                            <input type="text" class="form-control" id="customPosting" name="customPosting"
                                                   placeholder="Enter custom posting location" 
                                                   value="<?php 
                                                   $currentPostingValue = '';
                                                   if ($current_posting_data) {
                                                       $currentPostingValue = $current_posting_data['posting_location'];
                                                   } else {
                                                       $currentPostingValue = $employment_data['presentPosting'];
                                                   }
                                                   $found = false;
                                                   foreach ($nis_formations_flat as $code => $name) {
                                                       if ($currentPostingValue == $name) {
                                                           $found = true;
                                                           break;
                                                       }
                                                   }
                                                   echo (!$found && !empty($currentPostingValue)) ? htmlspecialchars($currentPostingValue) : ''; 
                                                   ?>">
                                        </div>
                                        <div class="text-muted mt-1">
                                            <i class="fas fa-info-circle"></i> This will update the Current Posting
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Posting Date Section -->
                                <div>
                                    <div class="date-container">
                                        <h4>
                                            <i class="fas fa-calendar-alt"></i> Posting Date (DD/MM/YYYY)
                                        </h4>
                                        <div class="mb-3">
                                            <label class="form-label required">Effective Date of Posting</label>
                                            <input type="date" class="form-control" name="posting_date" id="posting_date" required
                                                   value="<?php echo date('Y-m-d'); ?>"
                                                   max="<?php echo date('Y-m-d'); ?>">
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 2rem;">
                                <a href="search.php?serviceNo=<?php echo urlencode($serviceNo); ?>" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-save"></i> Update Posting
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Posting History -->
                <div class="posting-history-box">
                    <h3 class="info-title">
                        <i class="fas fa-history"></i> Posting History
                        <span style="font-size: 0.8rem; color: #666; margin-left: 1rem;">
                            (<?php echo count($posting_history); ?> records)
                        </span>
                    </h3>
                    
                    <?php if (!empty($posting_history)): ?>
                        <div style="overflow-x: auto;">
                            <table class="history-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Posting Location</th>
                                        <th>Posting Date</th>
                                        <th>Type</th>
                                        <th>Recorded On</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 1; ?>
                                    <?php foreach ($posting_history as $history): ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td>
                                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                                    <?php echo htmlspecialchars($history['posting_location']); ?>
                                                    <?php if ($current_posting_data && $history['posting_location'] === $current_posting_data['posting_location']): ?>
                                                        <span class="badge bg-success">
                                                            <i class="fas fa-check"></i> Current
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <?php 
                                                echo date('d/m/Y', strtotime($history['posting_date']));
                                                ?>
                                            </td>
                                            <td>
                                                <?php 
                                                $type_badge = '';
                                                $type_text = '';
                                                switch($history['posting_type']) {
                                                    case 'initial': 
                                                        $type_badge = 'bg-primary'; 
                                                        $type_text = 'Initial Posting';
                                                        break;
                                                    case 'transfer': 
                                                        $type_badge = 'bg-info'; 
                                                        $type_text = 'Transfer';
                                                        break;
                                                    case 'current': 
                                                        $type_badge = 'bg-success'; 
                                                        $type_text = 'Current';
                                                        break;
                                                    default: 
                                                        $type_badge = 'bg-secondary';
                                                        $type_text = ucfirst($history['posting_type']);
                                                }
                                                ?>
                                                <span class="badge <?php echo $type_badge; ?>">
                                                    <?php echo $type_text; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php 
                                                echo date('d/m/Y H:i', strtotime($history['created_at']));
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 2rem; color: #999;">
                            <i class="fas fa-history fa-2x" style="margin-bottom: 1rem;"></i>
                            <p>No posting history available for this personnel.</p>
                            <p class="text-muted">History will be created when you update the posting.</p>
                        </div>
                    <?php endif; ?>
                </div>

            <?php else: ?>
                <div class="alert alert-warning text-center">
                    <i class="fas fa-exclamation-triangle"></i> No personnel data found for this service number.
                </div>
                <div class="text-center">
                    <a href="search.php" class="btn btn-secondary">
                        <i class="fas fa-search"></i> Back to Search
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('postingForm');
        const presentPostingSelect = document.getElementById('presentPostingSelect');
        const customPostingContainer = document.getElementById('customPostingContainer');
        const customPostingInput = document.getElementById('customPosting');
        const postingDateInput = document.getElementById('posting_date');
        
        // Handle custom posting visibility
        if (presentPostingSelect && customPostingContainer) {
            // Initial check
            if (presentPostingSelect.value === 'other') {
                customPostingContainer.style.display = 'block';
                if (customPostingInput.value.trim() === '') {
                    customPostingInput.required = true;
                }
            }
            
            presentPostingSelect.addEventListener('change', function() {
                if (this.value === 'other') {
                    customPostingContainer.style.display = 'block';
                    customPostingInput.required = true;
                } else {
                    customPostingContainer.style.display = 'none';
                    customPostingInput.required = false;
                }
            });
        }
        
        // Format date display for user
        if (postingDateInput) {
            // Set today's date as default
            postingDateInput.value = new Date().toISOString().split('T')[0];
            
            // Add date format hint
            postingDateInput.addEventListener('change', function() {
                const date = new Date(this.value);
                const formattedDate = date.toLocaleDateString('en-GB'); // DD/MM/YYYY format
                console.log('Selected date:', formattedDate);
            });
        }
        
        // Handle form submission
        if (form) {
            form.addEventListener('submit', function(e) {
                // Validate custom posting
                const postingSelect = document.getElementById('presentPostingSelect');
                if (postingSelect && postingSelect.value === 'other' && customPostingInput) {
                    if (customPostingInput.value.trim() === '') {
                        e.preventDefault();
                        alert('Please enter a custom posting location.');
                        customPostingInput.focus();
                        return false;
                    }
                }
                
                // Validate posting date
                if (postingDateInput) {
                    const selectedDate = new Date(postingDateInput.value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    
                    if (selectedDate > today) {
                        e.preventDefault();
                        alert('Posting date cannot be in the future. Please select today\'s date or a past date.');
                        postingDateInput.focus();
                        return false;
                    }
                }
                
                // Format date for display in confirmation
                let formattedDate = 'Today';
                if (postingDateInput && postingDateInput.value) {
                    const date = new Date(postingDateInput.value);
                    formattedDate = date.toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    });
                }
                
                // Get posting location for confirmation
                let postingLocation = '';
                if (postingSelect) {
                    if (postingSelect.value === 'other' && customPostingInput) {
                        postingLocation = customPostingInput.value;
                    } else {
                        postingLocation = postingSelect.options[postingSelect.selectedIndex].text;
                    }
                }
                
                // Show confirmation with all details
                const confirmationMessage =
                    `Do you want to proceed?`;
                
                if (!confirm(confirmationMessage)) {
                    e.preventDefault();
                    return false;
                }
                
                return true;
            });
        }
    });
    </script>
</body>
</html>